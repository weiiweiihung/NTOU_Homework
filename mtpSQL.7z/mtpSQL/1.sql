select * from EasyCallMap ecm 

select * from WebAuth wa 

select * from TxnRecord where txn ='mtpQuery'order by qTime DESC

SELECT *from TxnRecord tr where txn = '/user/mtpUser03S'order by txnTime DESC 

select * from TxnRecord tr order by qTime DESC

select * from TxnRecord tr where txn like '%atmp%' order by qTime,txnTime DESC


select * from TxnRecord order by qTime,txnTime DESC
select * from EasyCallMap order by Sdate desc

select * from API a 

-- 對財金測試環境
--insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
--    , AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
--values ("fiscGreyQuery","https://openapigw.fisc-test.com.tw/darp/v1.0.0/designateAccount/query","POST","application/json"
--       ,"none","none","none","none","none","UTF-8","20231220");


--DROP TABLE GreyList;




with tempA as (
 select REPEAT_TIME as A from JobSchedule where STATUS = '00' and RUN_DATE<'2024/01/02' and CYCLE_TYPE='D' and '2024/01/02' <= START_DATE and  END_DATE<= '2024/01/02' and REPEAT_RUN ='Y'
 )
 SELECT
     code
     , content
 FROM tempA
 CROSS APPLY OPENJSON(A)
 WITH (
     code NVARCHAR(5) '$.code'
     , content NVARCHAR(5) '$.content'
 )WHERE content = '11:26'

 
 SELECT 
	IP
	,CID as '使用者統編'
	,JSON_VALUE(JSONSTR ,'$.loginid') as'使用者編號'
	,DATE as '日期及時間'
	,JSONSTR as '是否鎖定/鎖定時間'
  FROM [myebankLOGDB].[dbo].[EJ] with (nolock)
  where 
  (URI='/ebankC/res/sc000101002' and RR='1' and JSON_VALUE(JSONSTR ,'$.rc')='M0195')--登入作業 M0195(登入失敗，密碼錯誤)
  and SUBSTRING(DATE,1,7) in ('2023/10','2023/11','2023/12')
  group by CID,JSON_VALUE(JSONSTR ,'$.loginid'),URI,DATE,IP,JSONSTR
  order by CID,substring(DATE,1,10)
 
 
 
 
 
 
DROP TABLE Message

CREATE TABLE Message (
	 MID	[nvarchar]	(50)   NOT NULL DEFAULT('') --訊息代號
	,MNAME	[nvarchar]	(100)  NOT NULL DEFAULT('') --訊息
	,MDESC	[nvarchar]	(100)  NOT NULL DEFAULT('') --描述
	,MDESC2C[nvarchar]	(100)  NOT NULL DEFAULT('') --給客戶的訊息
	,MTYPE	[nvarchar]	(2)    NOT NULL DEFAULT('') --訊息類別(01:fisc-greyList)
)
insert into Message (MID, MNAME, MDESC, MDESC2C, MTYPE)
values 
  ('M000','成功'	    			,''                         						,'' ,'01')
, ('M999','失敗'	    			,''                         						,'' ,'01')
, ('200','OK'	                    ,'API處理成功，訊息格式請參閱Response Body'       	,'' ,'02')
, ('400','Bad Request'	            ,'業務應用檢核錯誤，訊息格式請參閱Response Body'    ,'' ,'02')
, ('401','Unauthorized'	        	,'未認證的請求，如API Key錯誤'                    	,'' ,'02')
, ('403','Forbidden'	            ,'未授權的訪問，如存取路徑未授權'                   ,'' ,'02')
, ('404','Not Found'	            ,'無法找到存取路徑(如：參加單位未上線)'             ,'查無資料' ,'02')
, ('500','Internal Server Error'	,'API內部程式無法處理'                           	,'' ,'02')
, ('503','Service Unavailable'	    ,'伺服器目前無法處理請求'                         	,'' ,'02')
;

SELECT  * from DataSet order by sName 

SELECT  * from DataSet ds where sKey like 'Ectype_%' order by sDate 
insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('System','Ectype_10j5','HQ0010J500'
,'21','20240119000000','none','0');


insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('System','fafp_keyid','48cd3e64-0e0c-48f6-b1ad-797191d702e3'
,'24','20250513000000','none','0');

select * from GreyList order by EXEC_ACTUAL_DATE desc

SELECT  * from EasyCallMap ecm order by Sdate 
SELECT  * from DataSet order by sName desc

select * from GreyList order by EXEC_ACTUAL_DATE desc
---------
SELECT  * from TxnRecord order by qTime  DESC 
SELECT  * from TxnRecord order by txnTime  DESC 
---------
select * from  JobSchedule where  QID = 'S001'

select * from GreyList 
where EXEC_DATE = '2024/01/26' 
and TO_FISC_STATUS != '1' 
-- and (FISC_RC ='06'  or FISC_RC = '') 
and FISC_RC in ('06','') 

select * from JobSchedule 

select * from GreyList order by 3 desc

select * from GreyList where API_SID='MTP0103001' order by 3 desc--問候擬祖宗18帶
--TO_FISC_STATUS 2代表exceptiom

select * from GreyList where EXEC_DATE = '2024/03/27' 
and TO_FISC_STATUS != '1' 
and FISC_RC in ('06', '') and SVC_TYPE in ('A02' , 'A03') 
--重送成功後就不用再重送，要「再次」重送的情境
--and (RETRY_RES ='' or ISNULL(JSON_VALUE(RETRY_RES,'$.appRepBody.result'),'')='06')
order by EXEC_ACTUAL_DATE

SELECT * from GreyList gl where FISC_RES ='辣醬魚肉'--time或者財金意外斷線重發情境

select * from GreyList gl order by RETRY_DAY desc


select * from TxnRecord tr order by qTime desc

select * from DataSet ds order by sDate 
select * from EasyCallMap ecm 



select * from GreyList 
where EXEC_DATE = '2024/03/27' 
and TO_FISC_STATUS != '1' 
and FISC_RC in ('06', '') and SVC_TYPE in ('A02' , 'A03') 
order by EXEC_ACTUAL_DATE

select * from EasyCallMap ecm 

https://openapigw.fisc-test.com.tw/darp/v1.0.0/{bankId}/designateAccount/notify

select * from EasyCallMap WHERE EcType ='HQ0010J500' or EcType ='NM00000001'
UPDATE EasyCallMap SET Url = 'https://172.16.5.105:443/EaiHub/resCommon/HostCommon' WHERE EcType='HQ0010J500'

UPDATE EasyCallMap SET Url = 'https://172.16.45.135:443/EaiHub/resCommon/HostCommon' WHERE EcType='HQ0010J500'
UPDATE EasyCallMap SET Url = 'https://172.16.45.135:443/EaiHub/resCommon/NotesMail' WHERE EcType='NM00000001'

SELECT  * from EasyCallMap where EcType ='CIP00query'

--整體有無問題
select * from GreyList with(nolock) order by EXEC_ACTUAL_DATE DESC 

--台企說10:39查詢有問題
select * from GreyList with(nolock) where OUT_ACC ='0500000' order by EXEC_ACTUAL_DATE DESC 

--null pointer 應在15:00 resend完成
select * from GreyList with(nolock) where STAN ='F294011' order by EXEC_ACTUAL_DATE DESC --MTP0102001

--null pointer 應在13:00 resend完成
select * from GreyList with(nolock) where STAN ='A293725' order by EXEC_ACTUAL_DATE DESC --MTP0102001

--null pointer
select * from GreyList with(nolock) where STAN ='X290147' order by EXEC_ACTUAL_DATE DESC --MTP0102001

select * from DataSet ds 


------------灰名單 風險閾值2024/04/08會議
select * from GreyList where API_SID ='MTP0101001'
and ISJSON(API_RES) > 0 
and JSON_VALUE(API_RES ,'$.rc')='P000'
and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'
order by EXEC_ACTUAL_DATE desc
------------

SELECT  * from TxnRecord tr order by RID DESC 

------------
select * from GreyList order by RETRY_DAY desc
select * from GreyList order by EXEC_ACTUAL_DATE desc
select  * from TxnRecord tr order by 1 DESC 
------------
select * from GreyList 
where EXEC_DATE = '2024/04/08' 
and TO_FISC_STATUS != '1' 
and FISC_RC in ('06', '') and SVC_TYPE in ('A02' , 'A03') 
order by EXEC_ACTUAL_DATE
select *
	from GreyList 
	where API_SID ='MTP0101001'--查詢
	and ISJSON(API_RES) > 0 
	and JSON_VALUE(API_RES ,'$.rc')='P000'
	and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'
	order by EXEC_ACTUAL_DATE desc



with tempA as (
	select 
		JSON_VALUE(API_RES,'$.body.appRepBody.account') as ACC
		,JSON_QUERY(API_RES,'$.body.appRepBody.channels') as A
	from GreyList 
	where API_SID ='MTP0101001'--查詢
		and EXEC_DATE between '2024/03/01' and '2024/04/30'--設定成動態參數
		and ISJSON(API_RES) > 0 
		and JSON_VALUE(API_RES ,'$.rc')='P000'
		and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'
)
select --count(*) as CountResult
	ACC
	,period
	,count
	,channelType
	
from tempA
CROSS APPLY OPENJSON(A)
WITH (
	period           NVARCHAR(MAX) '$.period'
	,count            NVARCHAR(MAX) '$.count'
	,channelType      NVARCHAR(MAX) '$.channelType'
) 
where (period ='2Y' and channelType='A' and count>10) --次數待確認，設定成動態參數
	or (period ='2Y' and channelType='B' and count>10) --次數待確認
	or (period ='2Y' and channelType='C' and count>10) --次數待確認
	or (period ='30d' and channelType='A' and count>10) --次數待確認
	or (period ='30d' and channelType='B' and count>10) --次數待確認
	or (period ='30d' and channelType='C' and count>10) --次數待確認
group by ACC,period,count,channelType
order by ACC,period,count,channelType
---------------------------------------------

with tempA as (
    select DISTINCT
        API_RES
    from GreyList 
    where API_SID ='MTP0101001' -- 查詢條件
        and EXEC_DATE between '2024/03/01' and '2024/04/30' -- 設定成動態參數 
        and ISJSON(API_RES) > 0 
        and JSON_VALUE(API_RES ,'$.rc')='P000' 
        and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'
        and JSON_QUERY(API_RES,'$.body.appRepBody.channels') !='[]'
),
tempB as (
    select
    ACC
    , A
    --, period
    --, [count]
    --, channelType 
    , SUM(CASE WHEN period = '2y' THEN [count] ELSE 0 END) AS sum_2y
    , SUM(CASE WHEN period = '30d' THEN [count] ELSE 0 END) AS sum_30d
    from tempA 
    CROSS APPLY OPENJSON(A) WITH (
        period NVARCHAR(MAX) '$.period'
        , [count] NVARCHAR(MAX) '$.count'
        , channelType NVARCHAR(MAX) '$.channelType'
    )
    GROUP BY A, ACC, channelType, [count]
)
select * from tempB












select *
    from dbo.GreyList                                                        
    where API_SID ='MTP0101001'                                         
        and EXEC_DATE between '2024/03/01' and '2024/04/30'      
        and ISJSON(API_RES) > 0
        and JSON_VALUE(API_RES ,'$.rc')='P000'
        and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'
        and JSON_QUERY(API_RES,'$.body.appRepBody.channels') !='[]'
        
        
       SELECT * from PROP_D order by 1
       
 select * from DataSet ds 
 
 select * from EasyCallMap ecm 
 
 select * from TxnRecord where txn like '%NM%'order by 1 DESC 
       
select * from GreyList order by EXEC_ACTUAL_DATE DESC 
  select DISTINCT                                         
    JSON_VALUE(API_RES,'$.body.appRepBody.account') as ACC,        
    JSON_QUERY(API_RES,'$.body.appRepBody.channels') as A          
    from GreyList                                                        
    where API_SID ='MTP0101001'                                         
        and EXEC_DATE between '2024/03/01' and '2024/03/31'                                    
        and ISJSON(API_RES) > 0                                    
        and JSON_VALUE(API_RES ,'$.rc')='P000'                          
        and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'        
        and JSON_QUERY(API_RES,'$.body.appRepBody.channels') !='[]'
        

        -- SELECT  * from TxnRecord tr order by 1
        --mtpUser01S 門號註冊
        SELECT  * from TxnRecord where txn ='/user/mtpUser01S'
        	and txnTime BETWEEN '2024/03/01' and '2024/03/31'
        	order by txnTime
        --mtpUser02S 門號變更
        SELECT  * from TxnRecord where txn ='/user/mtpUser02S'
        	and txnTime BETWEEN '2024/03/01' and '2024/03/31'
        	order by txnTime
        --mtpUser03S 門號查詢
        SELECT  * from TxnRecord where txn ='/user/mtpUser03S'
        	and txnTime BETWEEN '2024/03/01' and '2024/03/31'
        	order by txnTime
       	--mtpUser04S 門號註銷
        SELECT  * from TxnRecord where txn ='/user/mtpUser04S'
        	and txnTime BETWEEN '2024/03/01' and '2024/03/31'
        	order by txnTime
        
        select * from GreyList gl order by EXEC_ACTUAL_DATE DESC 
        SELECT  * from TxnRecord tr order by 1
   
        
        select * from MEMBER_ACCOUNT
CREATE TABLE MEMBER_ACCOUNT (
	ID			[nvarchar]	(50)	NOT NULL DEFAULT('')
    ,EMAIL		[nvarchar]	(50)	NOT NULL DEFAULT('')
    ,PASSWORD	[nvarchar]	(50)	NOT NULL DEFAULT('')
    ,ADDRESS		[nvarchar]	(50)	NOT NULL DEFAULT('')
    ,CELLPHONE	[nvarchar]	(50)	NOT NULL DEFAULT('')
    ,CREATE_DATE	[nvarchar]	(50)	NOT NULL DEFAULT('')
)

select  * from GreyList gl order by EXEC_ACTUAL_DATE DESC 




select DISTINCT                                         
    JSON_VALUE(API_RES,'$.body.appRepBody.account') as ACC,        
    JSON_QUERY(API_RES,'$.body.appRepBody.channels') as A          
    from GreyList                                                        
    where API_SID ='MTP0101001'                                         
        and EXEC_DATE between '2024/04/30'   and '2024/04/30'                                     
        and ISJSON(API_RES) > 0                                    
        and JSON_VALUE(API_RES ,'$.rc')='P000'                          
        and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'        
        and JSON_QUERY(API_RES,'$.body.appRepBody.channels') !='[]'
select * from PROP_D  

select * from DataSet ds where sKey like '%Cer%'
select * from EasyCallMap ecm where EcType ='mtpUnBind' 

select * from TxnRecord where txn='/user/mtpUser04KYC' order by 1 DESC 


select * from TxnRecord 

select * from PROP_D where DP_KEY like '%EAI_%'

select * from PROP_P where DP_KEY like '%EAI_%'



SELECT  * from TxnRecord tr order by RID DESC  --/user/mtpUser05S
SELECT  * from TxnRecord tr order by qTime DESC 
SELECT  * from TxnRecord tr order by txnTime DESC 

select * from DataSet ds 
select * from EasyCallMap ecm 
select * from WebAuth wa where ClientIP ='192.168.116.19'



select * from TxnRecord where SUBSTRING(txnTime,1,10) in ('2024/07/10','2024/07/11') and txn='/user/mtpUser04KYC'

select * from GreyList where EXEC_DATE ='2024/07/10'
select * from GreyList where EXEC_DATE ='2024/07/11'


select * from GreyList where EXEC_DATE='2024/07/10'
and TO_FISC_STATUS !='1'
and FISC_RC in ('06', '')
and SVC_TYPE in ('A02' , 'A03')
order by EXEC_ACTUAL_DATE

select * from GreyList where EXEC_DATE='2024/04/12' and SVC_TYPE in ('A02' , 'A03')


select * from GreyList where EXEC_DATE ='2024/07/15'

select * from mtp.dbo.TxnRecord where  txn='/user/mtpUser04KYC'
select * from mtp.dbo.TxnRecord where  txn='/user/mtpUser01O'

select * from GreyList order by EXEC_ACTUAL_DATE  DESC 


select * from mtp.dbo.TxnRecord order by RID  DESC

select * from EasyCallMap

select * from GreyList order by EXEC_ACTUAL_DATE desc

select * from GreyList where API_SID ='MTP0101001'

select * from EasyCallMap ecm

select * from TxnRecord where txn = 'kyc000001'order by 3 DESC 
select * from TxnRecord where txn = 'HQ00916V00' order by 3 DESC 

select * from TxnRecord where txn like '%getPreTransferInfo%'order by 3 DESC 
select * from TxnRecord order by 5 DESC 

select * from DataSet where sType ='System'

select * from EasyCallMap ecm 



select * from DataSet ds 
select * from EasyCallMap
-- 對財金測試環境
insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
    , AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
values ('fiscFafpMembers','https://openapigw.fisc-test.com.tw/fafp/v1.0.0/950/other/members','POST','application/json'
       ,'none','none','none','none','none','UTF-8','20250513');
	   
SELECT * from EasyCallMap
SELECT * from DataSet order by sName 

--DELETE FROM EasyCallMap WHERE EcType ='resCommonRestCommon2'
--DELETE FROM EasyCallMap WHERE EcType ='fiscFafpCertificates'
--DELETE FROM EasyCallMap WHERE EcType ='fiscFafpAccountQuery'
--DELETE FROM DataSet WHERE  sKey='Ectype_CIP00query'
SELECT * from TxnRecord where txn='mtpAccountInfoQry'order by qTime desc
SELECT * from TxnRecord order by txnTime desc

SELECT * from TxnRecord where qTime like '%2025/04/07 14%' order by qTime desc--2025/04/07 14:00:28.570
select * from Message m 

SELECT * FROM GreyList where STAN ='VHW07FP'order by 3 desc--下行要去掉多的

 SELECT * FROM GreyList where STAN ='0000049'order by 3 desc

SELECT * FROM GreyList where STAN ='0000032'order by 3 desc

 SELECT * FROM GreyList where API_SID ='MTP0201001' and FISC_RC ='02'order by 3 desc

 SELECT * FROM GreyList order by 3 desc
 
 
 SELECT * from TxnRecord where qTime like '%2025/04/07 14%' order by qTime desc--2025/04/07 14:00:28.570

 
 SELECT * FROM TxnRecord WHERE keyS1 ='mtp84565774'
 SELECT * FROM TxnRecord WHERE txn like '%mtpUser02S%' order by txnTime desc 
 SELECT * FROM TxnRecord WHERE keyS1 ='mtp36115545'
SELECT * FROM TxnRecord WHERE txn like '%mtpUser04S%' order by txnTime desc 
 SELECT * FROM TxnRecord WHERE keyS1 ='mtp78870534'
 -- 113年7月1日至114年4月30日期間曾使用手機門號轉帳服務中註冊、更新及取消功能之資料 (聯邦特有:臨櫃註銷)
 	--select * from TxnRecord WITH(NOLOCK) where txn = '/user/mtpUser04KYC' order by qTime desc --臨櫃註銷
 	select * from TxnRecord WITH(NOLOCK) where txn like '%atm%' order by txnTime desc --ATM
 	select * from TxnRecord WITH(NOLOCK) where txnTime like '2024/06/06 16%' order by txnTime desc --2024/06/06 16:15:54.430
 	select * from TxnRecord WITH(NOLOCK) where qTime like '2024/06/06 16%' order by txnTime desc --2024/06/06 16:15:54.430
 	select * from TxnRecord WITH(NOLOCK) where txn like '%SMS%' order by txnTime desc
 	--select * from TxnRecord WITH(NOLOCK) where qTime between '2024/07/01' and '2025/04/30'order by qTime desc --all
 
 	
 	
 	
 	
--只有註冊才有簡訊OTP
-- (註銷) /user/mtpUser04S
select
	CASE 
		--WHEN txn ='/user/mtpUser01O' THEN '註冊'
 		WHEN txn ='/user/mtpUser04S' THEN '取消'
 	END 類型
 	, '' as '客戶姓名' --請主機協助補
 	, '' as '身分證字號' --請主機協助補
 	, CASE
 		WHEN txn = '/user/mtpUser04S' THEN JSON_VALUE(inbound , '$.MobilePhone') ELSE ''
 	END '連結之手機門號'
 	, CASE
 		WHEN txn = '/user/mtpUser04S' THEN JSON_VALUE(inbound , '$.Account') ELSE ''
 	END '連結之帳戶'
 	, SUBSTRING(txnTime,1,10) as '取消日期'
 	, SUBSTRING(txnTime,12,19) as '取消時間'
 	, '線上'as '取消通路'
from TxnRecord
where txn ='/user/mtpUser04S'
order by txnTime

--select * from TxnRecord where 65480 < RID and RID < 65800 order by RID 
-- (註冊) /user/mtpUser01O
SELECT
    CASE 
        WHEN a.txn = '/user/mtpUser02S' THEN '變更'
    END AS 類型
    , '' AS 客戶姓名 -- 請主機協助補
    , '' AS 身分證字號 -- 請主機協助補
    , JSON_VALUE(a.inbound , '$.MobilePhone') AS '連結之手機門號'
    , JSON_VALUE(a.inbound , '$.OriAccount') AS '變更前帳戶'
    , JSON_VALUE(a.inbound , '$.UpdAccount') AS '變更後帳戶'
    , SUBSTRING(a.txnTime, 1, 10) AS '變更日期'
    , SUBSTRING(a.txnTime, 12, 19) AS '變更時間'
    , '線上' AS 註冊通路
    , SUBSTRING(b.qTime,1,10) as '發送OTP之日期'
 	, SUBSTRING(b.qTime,12,19) as '發送OTP之時間'
 	,JSON_VALUE(b.requestData , '$.PhoneNum') AS '發送OTP之門號'
FROM TxnRecord a
LEFT JOIN TxnRecord b
    ON a.keyS1 = b.keyS1
    AND b.txn = 'SMS0000001'
WHERE a.txn ='/user/mtpUser02S' and substring(a.txnTime,1,10) between '2023/07/01' and '2025/04/30'
ORDER BY a.txnTime, b.qTime











select * from GreyList with(nolock) order by EXEC_ACTUAL_DATE DESC 
--他行→自行
select
	CASE 
        WHEN API_SID = 'query' THEN '他行到自行-查詢'
        WHEN API_SID = 'notify' THEN '他行到自行-申請'
        WHEN API_SID = 'notifyCancel' THEN '他行到自行-取消'
    END AS '交易類型'
	, SUBSTRING(EXEC_ACTUAL_DATE,1,10) as '執行日期'
	, SUBSTRING(EXEC_ACTUAL_DATE,12,19) as '執行時間'
	, API_REQ 
	, API_RES
	--,IN_ACC_BANKCODE
	--,OUT_ACC_BANKCODE
from GreyList with(nolock)
where
	'2025/04/30'<EXEC_DATE
	and API_SID in('query','notify','notifyCancel')
	and OUT_ACC_BANKCODE !='8030000'
order by EXEC_ACTUAL_DATE

--自行到他行
select
	CASE 
        WHEN API_SID = 'MTP0101001' THEN '自行到他行-查詢'
        WHEN API_SID = 'MTP0102001' THEN '自行到他行-申請'
        WHEN API_SID = 'MTP0103001' THEN '自行到他行-取消'
    END AS '交易類型'
	, SUBSTRING(EXEC_ACTUAL_DATE,1,10) as '執行日期'
	, SUBSTRING(EXEC_ACTUAL_DATE,12,19) as '執行時間'
	, API_REQ 
	, API_RES
	--,IN_ACC_BANKCODE
	--,OUT_ACC_BANKCODE
from GreyList with(nolock)
where
	'2025/04/30'<EXEC_DATE
	and API_SID in('MTP0101001','MTP0102001','MTP0103001')
	and IN_ACC_BANKCODE !='8030000'
order by EXEC_ACTUAL_DATE


--自行到自行
select
	CASE 
		WHEN API_SID = 'query' THEN '他行到自行-查詢'
        WHEN API_SID = 'notify' THEN '他行到自行-申請'
        WHEN API_SID = 'notifyCancel' THEN '他行到自行-取消'
        WHEN API_SID = 'MTP0101001' THEN '自行到他行-查詢'
        WHEN API_SID = 'MTP0102001' THEN '自行到他行-申請'
        WHEN API_SID = 'MTP0103001' THEN '自行到他行-取消'
    END AS '交易類型'
	, SUBSTRING(EXEC_ACTUAL_DATE,1,10) as '執行日期'
	, SUBSTRING(EXEC_ACTUAL_DATE,12,19) as '執行時間'
	, API_REQ 
	, API_RES
	--,IN_ACC_BANKCODE
	--,OUT_ACC_BANKCODE
from GreyList with(nolock)
where
	'2025/04/30'<EXEC_DATE
	and API_SID in('MTP0101001','MTP0102001','MTP0103001','query','notify','notifyCancel')
	and (IN_ACC_BANKCODE ='803' and OUT_ACC_BANKCODE ='8030000')
order by EXEC_ACTUAL_DATE






---------

select * from DataSet order by sName 
select * from EasyCallMap ecm 

select * from GreyList gl order by EXEC_ACTUAL_DATE DESC 

---------


SELECT
    CASE 
        WHEN a.txn = '/user/mtpUser01S' THEN '註冊'
    END AS 類型
    , '' AS 客戶姓名 -- 請主機協助補
    , '' AS 身分證字號 -- 請主機協助補
    , JSON_VALUE(a.inbound , '$.MobilePhone') AS '連結之手機門號'
    , JSON_VALUE(a.inbound , '$.Account') AS '連結之帳戶'
    , SUBSTRING(a.txnTime, 1, 10) AS 註冊日期
    , SUBSTRING(a.txnTime, 12, 19) AS 註冊時間
    , '線上' AS 註冊通路
    , SUBSTRING(b.qTime,1,10) as '發送OTP之日期'
 	, SUBSTRING(b.qTime,12,19) as '發送OTP之時間'
 	,JSON_VALUE(b.requestData , '$.PhoneNum') AS '發送OTP之門號'
	,CASE 
		WHEN a.ip = '192.168.111.36' THEN '個網'
		WHEN a.ip = '192.168.111.41' THEN '行銀'
        WHEN a.ip = '192.168.111.66' THEN '數存'
		WHEN a.ip = '172.16.20.229' THEN 'KYC'
		WHEN a.ip = '172.16.20.230' THEN 'KYC'
		WHEN a.ip = '192.0.1.2' THEN 'AMTP'
    END AS IP
FROM TxnRecord_P20250616 a
LEFT JOIN TxnRecord_P20250616 b
    ON a.keyS1 = b.keyS1
    AND b.txn = 'SMS0000001'
WHERE a.txn = '/user/mtpUser01S' and substring(a.txnTime,1,10) between '2023/07/01' and '2025/04/30'
	and substring(b.qTime,1,10) between '2023/07/01' and '2025/04/30'
ORDER BY a.txnTime, b.qTime

SELECT  * from EasyCallMap ecm 




SELECT
    CASE 
        WHEN a.txn = '/user/mtpUser01S' THEN '註冊'
    END AS 類型
    , '' AS 客戶姓名 -- 請主機協助補
    , '' AS 身分證字號 -- 請主機協助補
    , JSON_VALUE(a.inbound , '$.MobilePhone') AS '連結之手機門號'
    , JSON_VALUE(a.inbound , '$.Account') AS '連結之帳戶'
    , SUBSTRING(a.txnTime, 1, 10) AS 註冊日期
    , SUBSTRING(a.txnTime, 12, 19) AS 註冊時間
    , '線上' AS 註冊通路
    --, SUBSTRING(b.qTime,1,10) as '發送OTP之日期'
 	--, SUBSTRING(b.qTime,12,19) as '發送OTP之時間'
 	,JSON_VALUE(b.requestData , '$.PhoneNum') AS '發送OTP之門號'
	,CASE 
		WHEN a.ip = '192.168.111.36' THEN '個網'
		WHEN a.ip = '192.168.111.41' THEN '行銀'
        WHEN a.ip = '192.168.111.66' THEN '數存'
		WHEN a.ip = '172.16.20.229' THEN 'KYC'
		WHEN a.ip = '172.16.20.230' THEN 'KYC'
		WHEN a.ip = '192.0.1.2' THEN 'AMTP'
    END AS IP
FROM TxnRecord_P20250616 a
LEFT JOIN TxnRecord_P20250616 b
    ON a.keyS1 = b.keyS1
    AND b.txn = 'SMS0000001'
WHERE a.txn = '/user/mtpUser01S' and substring(a.txnTime,1,10) between '2023/07/01' and '2025/04/30'
ORDER BY a.txnTime, b.qTime

--聯邦打財金照會他行，發「約定帳號查詢」從上個月1號至月底，取得account(約定帳號)以及channels(帳號存在各通路約定次數之訊息，為陣列會有多筆)
--條件是交易成功之交易、帳號存在且channels(帳號存在各通路約定次數之訊息)有值，並account和channels相同視為同一筆(即排除重複查詢)
--以上述撈出來的資料做資料處理：
--*** 1. period(約定週期:2y (當前2年含當日)、30d (前30天不含當日))
--*** 2. count(約定次數)
--以period作為key累計次數加總，如2y和30d在區間的數量加總，再計算出高風險閾值筆數
--達到「高風險閾值筆數計算方式：2y為15、30d為8」計入一次高風險閾值累計加總


SELECT  * from GreyList where API_SID ='MTP0101001' order by EXEC_ACTUAL_DATE desc



select DISTINCT                                         
    JSON_VALUE(API_RES,'$.body.appRepBody.account') as ACC,        
    JSON_QUERY(API_RES,'$.body.appRepBody.channels') as A,
    IN_ACC_BANKCODE 
    ,OUT_ACC_BANKCODE  
    from GreyList with(nolock)                                           
    where API_SID ='MTP0101001'                                         
        and EXEC_DATE between '2025/01/01' and '2025/05/31'                                     
        and ISJSON(API_RES) > 0                                    
        and JSON_VALUE(API_RES ,'$.rc')='P000'                          
        and JSON_VALUE(API_RES ,'$.body.appRepBody.result')='01'        
        and JSON_QUERY(API_RES,'$.body.appRepBody.channels') !='[]'
        
select * from TxnRecord where txn like '%mtpUser01S%' order by RID  DESC 
select * from TxnRecord where txn like 'HQ00916V00' order by 1

SELECT  * from GreyList_P20250616 glp where API_SID ='MTP0101001'order by EXEC_ACTUAL_DATE desc


SELECT  * from GreyList
where JSON_VALUE(API_REQ ,'$.account') = '0000010454545444' and ISJSON(API_REQ)>0
--IN_ACC in('0000007010276062','0000523501158718','0000001551290715','0020301800778259','0000031112120893') 
--where EXEC_DATE='2025/02/13'
order by EXEC_ACTUAL_DATE desc


{"account":"0000010454545444","bankCode":"805","darpStan":"G092237","initDateTime":"20250708092237"}
SELECT  * from GreyList order by EXEC_ACTUAL_DATE desc

select * from EasyCallMap where EcType ='mtpAccountInfoQry'
select * from DataSet ds 
select * from TxnRecord where keyI1 !='' order by keyI1



select * from GreyList where API_SID ='MTP0102001'order by EXEC_ACTUAL_DATE desc

insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
    , AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
values ('mtpAccountInfoQry','https://MNFT.fisc-test.com.tw/mtp/api/v2.0/user/accountInfoQry','POST','application/json'
       ,'none','none','none','none','none','UTF-8','20250513');

insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
    , AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
values ('mtpGetAccountInfoQry','https://MNFT.fisc-test.com.tw/v2.0/user/getAccountInfoQry','POST','application/json'
       ,'none','none','none','none','none','UTF-8','20250513');

      SELECT  * from TxnRecord order by RID desc
      
      SELECT  * from TxnRecord order by txnTime desc
      SELECT  * from TxnRecord order by qTime desc
      
      select * from  TxnRecord
      SELECT * from EasyCallMap where EcType like 'mtp%'
      
      select * from DataSet ds 
      
      select * from TxnRecord order by RID  DESC 
      
      select * from TxnRecord where txn like '%916V%'order by qTime desc 
      select * from GreyList gl order by 3 desc
      
      
      ------------
      select * from GreyList  order by 3 desc
      SELECT * from EasyCallMap order by Sdate 
      SELECT * from EasyCallMap where EcType  like 'mtp%'
      
      select * from WebAuth WHERE ClientIP IN ('172.16.68.009','192.168.116.141')
      select * from WebAuth WHERE ClientIP LIKE'%192.168.116.141%'
      
      SELECT * from EasyCallMap where EcType in('mtpUser','mtpChangeAccount','mtpQuery','mtpUnBind')
update EasyCallMap set Url='https://MNFT.fisc-test.com.tw/mtp/api/v2.0/user'						where EcType='mtpUser'				
update EasyCallMap set Url='https://MNFT.fisc-test.com.tw/mtp/api/v2.0/user/changeAccount'			where EcType='mtpChangeAccount'		
update EasyCallMap set Url='https://MNFT.fisc-test.com.tw/mtp/api/v2.0/user/query'					where EcType='mtpQuery'				
update EasyCallMap set Url='https://MNFT.fisc-test.com.tw/mtp/api/v2.0/user/unbind'					where EcType='mtpUnBind'			
update EasyCallMap set Url='https://MNFT.fisc-test.com.tw/mtp/api/v2.0/user/preTransferInfoQry'		where EcType='mtpPreTransferinfoQry'


select * from TxnRecord tr where txn like'%changedNotifyWithList%' order by txnTime desc

select * from DataSet order by sDate 


---
insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('System','Ectype_ZQ952A100v00','ZQ952A100v00'
,'27','20251007000000','none','0');
---

SELECT  * from EasyCallMap where Url like '%api/v2.0/user%'

select * from TxnRecord where SUBSTRING(qTime,1,10)='2025/10/30' or SUBSTRING(txnTime ,1,10)='2025/10/30'
order by qTime,txnTime desc

select * from GreyList where FISC_SOURCEID in('6000000','9520000','9970000')order by 3 desc 
select * from TxnRecord where txn like '%952%'order by qTime,txnTime desc
select * from ResMsg rm 

select * from FAFP WHERE EXEC_DATE = '2025/10/29' order by EXEC_ACTUAL_DATE DESC 

--DELETE FROM FAFP WHERE EXEC_DATE = '2025/10/29' and JSON_VALUE(API_REQ ,'$.notifyNo') ='1140160012'


select                                                                                                 
 	REPLACE(REPLACE(REPLACE(SUBSTRING(EXEC_ACTUAL_DATE,1,14), '/', ''),' ', ''),':', '') AS tractionDate 
 	,API_SID 
 	,JSON_VALUE(API_REQ ,'$.notifyBroadcastNo') as 'notifyBroadcastNo'                                   
 	,JSON_VALUE(API_REQ ,'$.notifyDate')        as 'notifyDate'                                          
 	,JSON_VALUE(API_REQ ,'$.notifyNo')          as 'notifyNo'                                            
 	,JSON_VALUE(API_REQ ,'$.notifyType')        as 'notifyType'                                          
 	,JSON_VALUE(API_REQ ,'$.notifyTypeMemo')    as 'notifyTypeMemo'                                      
 	,JSON_VALUE(API_REQ ,'$.bankId')            as 'bankId'                                              
 	,JSON_VALUE(API_REQ ,'$.account')           as 'account'                                             
 	,JSON_VALUE(API_REQ ,'$.accountType')       as 'accountType'                                         
 	,JSON_VALUE(API_REQ ,'$.idType')            as 'idType'                                              
 	,JSON_VALUE(API_REQ ,'$.isVirtualAccount')  as 'isVirtualAccount'                                    
 	,ACCINFO_ID as id                                                                                    
 	,ACCINFO_BIRTHDATE as birthDate                                                                      
 from FAFP                                                                                              
 WHERE EXEC_DATE = '2025/10/29'                                                                                           
   AND API_SID IN ('accountAlert/broadcastNotify','accountAlert/broadcastNotifyCancel')                 
   AND JSON_VALUE(API_REQ, '$.notifyBroadcastNo') not IN (                                                  
         SELECT JSON_VALUE(API_REQ, '$.notifyBroadcastNo')                                              
         FROM FAFP                                                                                      
         WHERE EXEC_DATE = '2025/10/29'                                                                                     
           AND API_SID IN ('accountAlert/broadcastNotify','accountAlert/broadcastNotifyCancel')         
           AND JSON_VALUE(API_REQ, '$.notifyBroadcastNo') IS NOT NULL                                   
         GROUP BY JSON_VALUE(API_REQ, '$.notifyBroadcastNo')                                            
         HAVING COUNT(DISTINCT API_SID) = 2                                                             
   )                             
---





select * from DataSet ds where sKey ='Ectype_HQ0016W800'

select * from EasyCallMap ecm where EcType ='HQ00A64039'

select * from FAFP where FISC_STAN in('0058502'
,'0058357'
,'0058336'
,'0058329'
,'0058270'
,'0058263'
,'0058251'
,'0058208'
,'0058190'
,'0058173'
,'0058153'
,'0058072'
,'0058068'
,'0057927'
)

select * from FAFP f2 order by EXEC_ACTUAL_DATE desc
where ISJSON(API_RES) > 0
and JSON_VALUE(API_REQ ,'$.account') in('0078195000000000','7770000000434327') order by EXEC_ACTUAL_DATE  desc

select * from FAFP where API_SID ='accountAlert/broadcastNotify' and ACCINFO_ID ='A123456789'order by EXEC_ACTUAL_DATE DESC 
select * from FAFP where API_SID ='accountAlert/broadcastNotify'order by EXEC_ACTUAL_DATE DESC 

select  * from TxnRecord tr
select * from EasyCallMap 


SELECT  * from TxnRecord tr where txn ='HQ0016W800'order by qTime DESC 
SELECT  * from TxnRecord tr order by txnTime DESC 


select * from GreyList order by 3 desc


select * from FAFP order by 4 desc

select * from FAFP_MF_LOG order by 4 desc

select * from GreyList gl order by 3 

select * from PROP_D






-- 通報16W8
-- 取消
-- accountAlert/queryUserID 查詢
-- accountAlert/broadcastNotify 申請
-- accountAlert/broadcastNotifyCancel 取消
  SELECT * FROM FAFP_MF_LOG
  where EXEC_DATE between '2025/12/01' and '2025/12/31'
  and SID='accountAlert/broadcastNotify'
  and ISJSON(REQ) >0
  and JSON_VALUE(REQ,'$.TxnType')='HQ0016W800'
  
  
  

  
  
  
  
  select * from FAFP_MF_LOG order by 4 DESC 
  
  --TRUNCATE table FAFP_MF_LOG
  
  
  
  select * from EasyCallMap where EcType ='HQ00C64039'

  --"TxnType":"HQ0016W800"
  select * from FAFP_MF_LOG
  where SID ='accountAlert/broadcastNotify'
  --and FISC_RTN_ID !=''
  and ISJSON(REQ)>0
  and JSON_VALUE(REQ,'$.TxnType')='HQ0016W800'
  order by EXEC_ACTUAL_DATE  desc 

  select * from FAFP_MF_LOG
  where FISC_RTN_ID !=''
  
  select * from PROP_P pp 
  
  
  select * from EasyCallMap ecm 
  --WSBB1551 019775000244
  --HKBR0188
  

  
  select * from FAFP_MF_LOG
  --where EXEC_DATE ='2025/12/15'and
  -- ISJSON(REQ)>0
  --and JSON_VALUE(REQ,'$.QueryID')='WSBB1551A' 
  --and JSON_VALUE(REQ,'$.TxnType')='HQ00C64039'
  --where FISC_RTN_ID like '%H226155626%'
  order by EXEC_ACTUAL_DATE desc
  select * from FAFP where FISC_STAN ='0058251'
select * from FAFP where FISC_STAN in('0055831'
,'0055832'
,'0055749'
,'0055744'
,'0055713'
,'0055537'
,'0055531'
,'0055491'
,'0055010'
,'0055007'
,'0055004'
,'0054852'
,'0054849'
,'0055116'
,'0055096'
,'0054972'
,'0055449'
,'0055409'
,'0055405'
,'0055395'
,'0055386'
,'0055365'
,'0055285'
,'0055258'
,'0055256'
,'0055210'
,'0055198'
,'0055155'
,'0055153'
)
and FIS

select * from PROP_P where DP_KEY = 'EMAIL_COMPLIANCE_DEPARTMENT'

select * from EasyCallMap ecm 



--------------
SELECT *
FROM TxnRecord
WHERE
    ISJSON(requestData) > 0
    AND (
        ( txn = 'ZQ916Q00v00'
          AND JSON_VALUE(requestData, '$.SV916Q_ACC') = '7777777777777777'
        )
        OR
        ( txn = '/user/getAccountInfoQry'
          AND JSON_VALUE(requestData, '$.ReqBody.Account') = '7777777777777777'
        )
    )
order by RID
--------------
SELECT * FROM TxnRecord 
WHERE txn = 'ZQ916Q00v00' 
	and ISJSON(requestData)>0 
	and JSON_VALUE(requestData,'$.SV916Q_ACC')='7777777777777777'
	

SELECT * FROM TxnRecord 
WHERE txn = '/user/getAccountInfoQry'
	and ISJSON(requestData)>0 
	and JSON_VALUE(requestData,'$.ReqBody.Account')='7777777777777777'