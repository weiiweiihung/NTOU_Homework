
insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('System','Ectype_NM01','NM00000001'
,'22','20240219000000','none','0');
