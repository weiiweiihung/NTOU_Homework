
insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('FiscConfig','greyXSourceId','8030000'
,'19','20240116000000','none','0');

--測試環境
--insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
--values ('FiscConfig','greyXKeyID','82b76c5e-b338-4400-bdff-ceea3d4b3172'
--,'20','20240116000000','none','0');

--正式環境
insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('FiscConfig','greyXKeyID','???????????????????'--!!!!!!!!!!!記得要補上!!!!!!!!!!!
,'20','20240116000000','none','0');