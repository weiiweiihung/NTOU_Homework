
insert into DataSet (sType, sKey, sValue, sName, sDate, sPs, status)
values ('System','Ectype_10j5','HQ0010J500'
,'21','20240119000000','none','0');
