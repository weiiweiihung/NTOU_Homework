insert into JobSchedule
(
	QID			
	,DO_CLASS_NAME	
	,TODO_DESC		
	,CYCLE_TYPE		
	,START_DATE		
	,END_DATE		
	,REPEAT_RUN		
	,REPEAT_TIME	
	,RUN_DATE	    
	,RUN_TIME	    
	,STATUS
)values(
	'S001'
	,'com.ubot.schedule.job.GreyListJob'
	,'灰名單mtp至財金失敗重送機制'
	,'D'
	,'2024/01/02'
	,''		--排程結束 yyyy/mm/dd；若空代表無結束日期
	,'Y'
	,'[{"code":"1","content":"09:00"},{"code":"2","content":"10:00"},{"code":"3","content":"11:00"},{"code":"4","content":"12:00"},{"code":"5","content":"13:00"},{"code":"6","content":"14:00"},{"code":"7","content":"15:00"},{"code":"8","content":"16:00"},{"code":"9","content":"17:00"},{"code":"10","content":"18:00"},{"code":"11","content":"19:00"},{"code":"12","content":"20:00"},{"code":"13","content":"21:00"},{"code":"14","content":"22:00"},{"code":"15","content":"23:00"}]'
	,''   	--已執行日期YYYY/MM/DD
	,''   	--已執行時間HH:MM:SS.SSS
	,'00'
)