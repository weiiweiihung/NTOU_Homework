CREATE TABLE JobSchedule (
	QID				[nvarchar]	(4)   NOT NULL DEFAULT('') UNIQUE--‘’	ScheduleID編碼規則：S001
	,DO_CLASS_NAME	[nvarchar]	(MAX) NOT NULL DEFAULT('') --‘’		將執行的Class Name
	,TODO_DESC		[nvarchar]	(20)  NOT NULL DEFAULT('') --‘’		執行敘述
	,CYCLE_TYPE		[nvarchar]	(1)   NOT NULL DEFAULT('') --‘’		執行類型D:當日
	,START_DATE		[nvarchar]	(10)  NOT NULL DEFAULT('') --‘’		排程開始 yyyy/mm/dd
	,END_DATE		[nvarchar]	(10)  NOT NULL DEFAULT('') --‘’		                 
	,REPEAT_RUN		[nvarchar]	(1)   NOT NULL DEFAULT('') --‘’		重複執行? Y：是, N：否
	,REPEAT_TIME	[nvarchar]	(MAX) NOT NULL DEFAULT('') --‘’		預計重複執行時間[{"code":"1","content":"12:00"},{"code":"2","content":"18:00"}]
	,RUN_DATE		[nvarchar]	(10)  NOT NULL DEFAULT('') --‘’		已執行日期YYYY/MM/DD
	,RUN_TIME		[nvarchar]	(12)  NOT NULL DEFAULT('') --‘’		已執行時間HH:MM:SS.SSS
	,STATUS			[nvarchar]	(2)   NOT NULL DEFAULT('') --‘’		狀態00:正常,99:註銷
)