select * from GreyList
where EXEC_DATE = '2024/01/05' 
and TO_FISC_STATUS != '1'
and (FISC_RC = '06' or FISC_RC = '')order by EXEC_ACTUAL_DATE 

select * from TxnRecord tr order by qTime DESC--OTP密碼


SELECT * FROM [mtp].[dbo].[GreyList] order by EXEC_ACTUAL_DATE desc

select * from USERS where CID  =''

select * from MESSAGE m 


select * from EJ2HUB where HUB_API like 'HQ00A94S%'order by 5 DESC 

select * from EJ2HUB where HUB_API like 'FX00FRN31S%'order by 5 DESC 


SELECT * FROM MAPUST WHERE CID = 'VGAG0159A' AND UID = 'admin1' AND STATUS != '99'


SELECT * FROM SERVICES WHERE SID='SC03-05-01-001' AND STATUS='1'

select * from EJ2HUB where HUB_API  like '%ws%'order by 5 DESC --where CID ='VGAG0159A'order by 5 DESC 

select* from FUND_QUEUE fq order by 1 desc --FUND20240126104151775

select * from MESSAGE_EXTEND where MEID like '%E999%'

select * from PROPERTIES_P pp 

select * from EJ2HUB where CLASSNAME like '%030301003%' 
--and ISJSON(OUTBOUND) > 0 
--and JSON_VALUE('OUTBOUND','$.rc')='EI02' 
order by 5 DESC 

SELECT  * from BATCHLIST b 

SELECT * FROM USERS WHERE CID='VGAG0159A' AND UID='admin1' AND STATUS in ('00','01','50','90','98')

SELECT * FROM FLOWSCONTROL_SN WHERE CID='VGAG0159A' AND FCID='FC20240126144216682' AND STATUS NOT IN('98','99') ORDER BY FCID DESC


select * from TX_QUEUE order by 3 desc

select * from PROPERTIES_P where P_KEY ='SENDER'-

SELECT * from EJ2HUB eh where CID ='97100440A' order by INBOUNDTIME  DESC

select * from CUSTOMER c where CID ='E109553507A'


select *  from EJ2HUB where CID ='23473992A'order by 5 desc

SELECT * FROM CUSTOMER WHERE CID = '23473992A' AND STATUS != '99'

SELECT * FROM ACCOUNT WHERE CID = '23473992A' AND ACCTYPE = 'PO' AND STATUS != '99' AND CURRENCY = ?


SELECT * FROM ( SELECT * FROM ACCOUNT WHERE 
	CID = '23473992A' AND MF_STATUS = '00' AND CURRENCY = '0' AND STATUS != '99' 
	AND (	(ACCTYPE = 'RA' AND AUTH = '1')	OR (ACCTYPE = 'PO' AND AUTH = '1')	)
) 
AS ACCOUNT INNER JOIN (
	SELECT * FROM MAPUA WHERE CID = '23473992A' AND UID = 'admin1' AND FLAG_T = '1' AND STATUS != '99'
) 
AS MAPUA ON(ACCOUNT.CID = MAPUA.CID AND ACCOUNT.ACCID = MAPUA.ACCID) 
INNER JOIN ( SELECT * FROM LIMITCONFIG WHERE CID = '23473992A' AND TYPE = '03' AND STATUS != '99') 
AS LIMITCONFIG ON(ACCOUNT.CID = LIMITCONFIG.CID AND ACCOUNT.ACCID = LIMITCONFIG.TARGET) 
ORDER BY ACCOUNT.RCID


SELECT * FROM ACCOUNT 
WHERE CID = '23473992A'
AND MF_STATUS = '00' 
AND CURRENCY = '0' AND STATUS != '99' 
AND ((ACCTYPE = 'PO' AND AUTH = '1'))

SELECT * FROM MAPUA WHERE CID = '16094897A' AND UID = 'admin1' AND FLAG_T = '1'

SELECT * FROM CUSTOMER WHERE CID = '16094897A' AND STATUS != '99'
SELECT * FROM CUSTOMER WHERE CID = '16094897A' AND STATUS != '99'

SELECT * FROM ACCOUNT WHERE CID = '16094897A' AND ACCTYPE = 'PO' AND STATUS != '99' AND CURRENCY = ?


SELECT * FROM ACCOUNT 
WHERE CID = '16094897A' AND MF_STATUS = '00' AND CURRENCY = '0' AND STATUS != '99' 
AND ((ACCTYPE = 'PO' AND AUTH = '1'))


SELECT * FROM MAPUA WHERE CID = '16094897A' AND UID = 'admin1' AND FLAG_T = '1'

select * from EJ2HUB where CID ='28672078A'order by 5 DESC 

select * from EJ2HUB where CID ='24430037A' and HUB_API like '%cert%'order by 5 DESC


select * from MESSAGE where MID='M9901O'

SELECT TOP (1000) *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  WHERE HUB_API = 'otp0000017'
  --AND CID = 'xxx'
  --AND UID = 'xxx'
  --AND SUBSTRING(INBOUNDTIME ,1,10) = '2023/06/03'
  ORDER BY INBOUNDTIME DESC
  
  
  
  
  select * from PROPERTIES_P where P_KEY like '%HUBService_URL%' or P_KEY like '%EAI_URI%'
  
  SELECT *  from EJ2HUB where CLASSNAME ='SC040401002'order by 5 DESC
  
  
  
  select * from CERTIFICATE where UBKEY_SN ='2014101511'--KEEPER ='84742479A' 
  
  
  SELECT  * from CERTIFICATE where KEEPER ='13001973A'
  
  select * from USERS u
  
  select * from FUND_QUEUE where FUNDQ_SERVICENUM ='' 
  and FUNDQ_EXEC_DATE between '' and '' order by FUNDQ_EXEC_DATE
  
  

  
  
  
  
  
  
  
  
  
  
  
  
  select * from FUND_QUEUE fq 
  
  
  
  

	select * from EJ2HUB order by 5 desc
	SELECT  * from FUND_QUEUE fq where FUNDQ_FCID ='FC20240506103622959'order by FUNDQ_RC1_SDATE DESC 
	
	
DECLARE @startDate VARCHAR(10)='2024/01/01'
DECLARE @endDate VARCHAR(10)='2024/12/31'

--基金區
  SELECT
  		CASE
			WHEN FUNDQ_SERVICENUM = 'A01' THEN '基金申購'
		END 類型
		,SUBSTRING(FUNDQ_EXEC_DATE,0,11)as'日期'
		,SUM(CAST(FUNDQ_RC1_TotalCount as bigint))as'總筆數'
		,CURRENCY as '幣別'
		,SUM(CAST(REPLACE(AMOUNT,',','') as float))as'總金額'
		,SUM(CAST(REPLACE(A_FEE,',','') as float))as'手續費'
	from FUND_QUEUE with(nolock)
	where FUNDQ_SERVICENUM ='A01'
	and FUNDQ_EXEC_DATE BETWEEN @startDate and @endDate
	GROUP by SUBSTRING(FUNDQ_EXEC_DATE,0,11),CURRENCY,FUNDQ_SERVICENUM
	
	select * from PROPERTIES_P where P_KEY like'%EZ%' 
	
SELECT * FROM   TX_QUEUE WHERE 	 TXQ_SID   = 'SC030102002DO' AND   TXQ_CID	  = '99360890A' AND   TXQ_STATUS   IN ('1', '3') AND SUBSTRING(TXQ_EXEC_ACTUAL_DATE ,1,10) = '2024/05/06'


select * from CERTIFICATE where KEEPER ='96919464A'




delete from TX_QUEUE WHERE 	 TXQ_SID   = 'SC030102002DO' AND   TXQ_CID	  = '99360890A' AND   TXQ_STATUS   IN ('1', '3') AND SUBSTRING(TXQ_EXEC_ACTUAL_DATE ,1,10) = '2024/05/06'

select * from BATCHLIST order by 1  where BMETHOD in('doBatch6','doBatch9','doBatch11','doBatch12')




SELECT * FROM [dbo].[PROPERTIES_P] WHERE [P_KEY] like'%SMS%'
UPDATE [dbo].[PROPERTIES_P] SET [P_VALUE]='ebank' WHERE [P_KEY]='SMS_ID'

--UPDATE [dbo].[PROPERTIES_P] SET [P_VALUE]='Ubsms@3654' WHERE [P_KEY]='SMS_PWD'
UPDATE BATCHLIST 
SET BDATE = 'YYYY/MM/DD' 
where BMETHOD in('doBatch6','doBatch9','doBatch11','doBatch12')

select * from TX_QUEUE tq order by TXQ_EXEC_ACTUAL_DATE DESC 

select * from ACH_QUEUE order by 1  DESC 

select * from ACH_DATA ad order by 3 desc


select * from myebankLOGDB.dbo.EJ2HUB where HUB_API like'%9159%' order by 5 DESC --2024/05/09 13:36:31.313


SELECT * from TX_QUEUE














BETWEEN '2023/01/01' AND '2023/12/31'



SELECT  CASE     WHEN TXQ_SID = 'SC030101002DO' THEN '台幣單筆'    WHEN TXQ_SID = 'SC030102002DO' THEN '台幣整批'    WHEN TXQ_SID = 'SC030201002DO' THEN '台幣薪資'  END type    ,TXQ_EXEC_DATE AS date    , SUM(CAST(TXQ_RC1_TotalCount AS INT)) AS totalCount    , '台幣' AS '幣別'    , SUM(CAST(AMOUNT AS MONEY)) AS totalAmt  FROM TX_QUEUE with(nolock)  WHERE    TXQ_SID IN ('SC030101002DO', 'SC030102002DO', 'SC030201002DO')    AND TXQ_EXEC_DATE BETWEEN '2023/01/01' AND '2023/12/31'  GROUP BY TXQ_EXEC_DATE, TXQ_SID



















SELECT
	CASE 
		WHEN TXQ_SID = 'SC030501002DO' THEN '外幣單筆'
		WHEN TXQ_SID = 'SC030503002DO' THEN '外幣匯款'
	END 類型
	,TXQ_EXEC_DATE AS '日期'
	, SUM(CAST(TXQ_RC1_TotalCount AS INT)) AS '總筆數'
	, CASE
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '00' THEN 'TWD/新臺幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '01' THEN 'USD/美金'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '02' THEN 'DEM/馬克'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '03' THEN 'JPY/日幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '04' THEN 'GBP/英鎊'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '05' THEN 'AUD/澳幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '06' THEN 'HKD/港幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '07' THEN 'CAD/加拿大幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '08' THEN 'CNY/人民幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '09' THEN 'BEF/比利時法郎'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '10' THEN 'FRF/法國法郎'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '11' THEN 'NLG/荷蘭幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '12' THEN 'SGD/新加坡幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '13' THEN 'ZAR/南非幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '14' THEN 'SEK/瑞典克郎'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '15' THEN 'CHF/瑞士法郎'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '16' THEN 'ITL/義大利里拉'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '17' THEN 'THB/泰國銖'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '18' THEN 'NZD/紐西蘭幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '19' THEN 'MYR/馬來西亞幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '20' THEN 'ESB/西班牙幣'
		WHEN JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency') = '21' THEN 'EUR/歐元'
		END 幣別
	, SUM(CAST(JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayAmount') AS MONEY)) AS '總金額'
	FROM TX_QUEUE with(nolock)
	WHERE
		TXQ_SID IN ('SC030501002DO', 'SC030503002DO')
		AND ISJSON(TXQ_RC1_RESULT) > 0 
		AND TXQ_EXEC_DATE BETWEEN '2023/01/01' AND '2023/12/31'
	GROUP BY 
		TXQ_EXEC_DATE,TXQ_SID,JSON_VALUE(TXQ_RC1_RESULT, '$.tranData.PayCurrency')
		
		
		select * from [myebankDB_P1120301].[dbo].[FUND_QUEUE] order by FUNDQ_RC1_SDATE desc
		
				select * from MESSAGE m 
				
				
				
				select * from CERTIFICATE c2 where KEEPER ='84742479A' order by CDATE  DESC 
				
select * from [myebankLOGDB].[dbo].[EJ2HUB] with(nolock) where CID ='52570683A' and CLASSNAME='SC000103001' order by 5 DESC --where CLASSNAME='SC000103001'
select * from [myebankLOGDB].[dbo].[EJ] with(nolock) where CID ='52570683A' and URI='/ebankC/res/sc000103001' order by DATE DESC

select * from FLOWSCONTROL with(nolock)WHERE CID='52570683A' AND DO_STATUS='0' AND DO_RESULT='' AND STATUS_A='0' AND STATUS_C <> '0' AND STATUS NOT IN('44','98','99') ORDER BY FCID DESC

		select * FROM MESSAGE where MID ='BE41120'
		
		DELETE from MESSAGE where MID ='BE41210'
		
		select * from FUND_QUEUE fq 
		
		
		
		
		
		
		
		select * from TOKEN_ALL ta order by CDATE DESC 
		
		
		
		
		
		--現在線上有多少人?(AP日期寫死當天)
		SELECT COUNT(CID) as nowLoginCount 
		from TOKEN with(nolock)
		where SUBSTRING(CDATE,1,10)='2024/05/14'
		and STATUS ='00'
		
		--今昨日小時登入次數統計(AP日期寫死當天和前一天)
		SELECT SUBSTRING(CDATE,1,13)as date, COUNT(CDATE) as loginCount
		from TOKEN with(nolock)
		where SUBSTRING(CDATE,1,10) in ('2024/09/03','2024/09/02')
		group by SUBSTRING(CDATE,1,13)
		order by SUBSTRING(CDATE,1,13)
		
		select * from TOKEN_ALL ta 
		--統編區間次數統計(只能查一個月)
		select CID, SUBSTRING(CDATE,1,10) as date, COUNT(CDATE) as loginCount
		from TOKEN_ALL with(nolock)
		where CDATE between '2024/01/01' and '2024/02/29'
		group by CID, SUBSTRING(CDATE,1,10)
		order by SUBSTRING(CDATE,1,10)
		
		
		
		--系統註冊有效客戶總數統計
		SELECT COUNT(CID)as count from CUSTOMER with(nolock)
		
		--客戶類型統計，告知AQ是啥
		select MTYPE, SITEMS, COUNT(CID)as count from CUSTOMER with(nolock) group by SITEMS, MTYPE--A:全功能

		--分行開戶統計數
		select CBRANCH, COUNT(CBRANCH)as count from CUSTOMER with(nolock) group by CBRANCH

		select * from CUSTOMER c 
		
select CID, SUBSTRING(CDATE,1,10) as date, COUNT(CDATE) as loginCount from TOKEN_ALL with(nolock) where CDATE between '2024/08/03' and '2024/09/03' group by CID, SUBSTRING(CDATE,1,10) order by SUBSTRING(CDATE,1,10)


select * from [myebankLOGDB].[dbo].[EJ2HUB] with(nolock) order by 5 desc
		select * from [myebankLOGDB].[dbo].[EJ] with(nolock) order by DATE desc
		
		select * from CERTIFICATE where KEEPER ='12959786A'order by CDATE 
		--where UBKEY_SN ='2014101509' --201903050002
		
		select * from MAPUC m  where CertID ='201903050002'
		INSERT INTO MAPUC
--  (CID 
-- ,[BRANCHCODE]
--  )
  VALUES
 ('12959786A'
 ,'admin1'
 ,'201903050002'
 ,'00')
		
		select * from MESSAGE order by 1  where MID ='0021'
		select * from SYS_CONFIG sc 
		select * from SYS_CONFIG
		
		select * from API a 
		
		select * from PROPERTIES_P where P_KEY ='WARNLIST'
		
		
		
		select * from [myebankLOGDB].[dbo].[EJ] where URI like '%sc030503001%' and CID ='84742479A'order by [DATE] desc
select * from [myebankLOGDB].[dbo].[EJ2HUB] where CLASSNAME = 'SC030503001DO'order by 5 DESC 

select * from [myebankLOGDB].[dbo].[EJ2HUB] order by 5 DESC 


SELECT FSQIN05OUT FROM ETF_QUEUE order by ETFQ_EXEC_ACTUAL_DATE DESC 



select * from CERTIFICATE c2  where KEEPER = '96919464A' order by MDATE  DESC 


		select * from [myebankLOGDB].[dbo].[EJ2HUB] with(nolock) 
		where CID ='84742479A'
		order by 5 desc



select * from USERS u  where UID ='23285582A' or UID ='84742479A'
select * from CUSTOMER c where CID ='23285582A' or CID='84742479A'


select * from EJ2HUB eh 
WITH(NOLOCK)
where HUB_API = 'nm00000001' 
and CLASSNAME ='SC000102001'
and CID ='23285582A' 
order by INBOUNDTIME desc

select * from [myebankLOGDB].[dbo].[EJ2HUB] 
WITH(NOLOCK)
where HUB_API = 'nm00000001' 
and CLASSNAME ='SC000102001'
and CID ='23285582A' 
order by INBOUNDTIME desc



select * from [myebankLOGDB].[dbo].[EJ2HUB] 
WHERE CID ='80071033A'
order by 5 DESC

select * from USERS where CID ='23285582A'

select * from TX_QUEUE 








select * from [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK) 
where SUBSTRING(INBOUNDTIME,1,10)='2024/03/01' 
and HUB_API like'%57S%'
order by 5 DESC 


SELECT SUBSTRING(txq.TXQ_EXEC_ACTUAL_DATE,0,20) AS date,
txq.TXQ_RC1_Count AS count,
txq.TXQ_RC1_RESULT AS json,
cut.CBRANCH AS CBranch
From TX_QUEUE txq WITH(NOLOCK)
JOIN CUSTOMER AS cut on txq.TXQ_CID = cut.CID
where txq.TXQ_SID = 'SC030503002DO'
and txq.TXQ_STATUS in ('1','3')		
and txq.TXQ_EXEC_DATE = '2024/03/01'
ORDER BY cut.CBRANCH, txq.TXQ_CID, txq.TXQ_EXEC_ACTUAL_DATE


select * from ARPINST.USER 
where ACC='1075331' and TYPE=? and ( fileList like ? or fileList='all' )

select * from USERS u where CID ='23285582A'


SELECT *
  FROM [myebankLOGDB].[dbo].[EJ] WITH(NOLOCK) 
  --where CID ='23285582A'
  order by [DATE] desc
  
  select * from [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK) where CID ='80071033A'order by 5 DESC 
  
  select * from API where API_ID ='SC021103001'
  
--  delete from API where API_ID ='SC021101001'
  
  select * from PROPERTIES_T pp where P_KEY ='EAI_URI_CRD'
  
  select * from SERVICES s where SID like '%SC02-11%'
  
  
  
  SELECT * from TX_QUEUE where TXQ_FCID not in (select TXQ_FCID from TX)
  
  select * from [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK) 
  where HUB_API like '%a038%'
  order by 5 DESC 

  select * from [myebankLOGDB].[dbo].[EJ] WITH(NOLOCK) 
  --where HUB_API like '%a038%'
  where CID ='01012813A'
  and URI ='/ebankC/res/sc040203002'
  order by 5 DESC 
  
select * from PROPERTIES_P where P_KEY like '%EAI_URI_CRD%'
select * from PROPERTIES_T where P_KEY like '%EAI_URI_CRD%'
select * from PROPERTIES_U where P_KEY like '%EAI_URI_CRD%'



select * from myebankLOGDB.dbo.EJ2HUB  where HUB_API like'%cert%13'

select * from EJ2HUB  where HUB_API like'%cert%13' and CID ='53534047A'

select * from myebankLOGDB.dbo.EJ  where URI='/ebankC/res/sc040401012'and CID ='53534047A'

C441C7

select * from API where API_ID ='SC040401003'





select * from MAPUR where CID ='01941418A'order by CID --01941418A

select * from [dbo].[MAPUR] with(nolock) WHERE UID like '%[^A-Za-z0-9]%'


select * from [myebankLOGDB].[dbo].[EJ2HUB] 
where HUB_API ='Crd00B114'--SC021102001
--and JSON_VALUE('OUTBOUND','$.result.data.headerRec.dispStmtCnt')='0' 
and ISJSON(OUTBOUND) > 0 
order by 5 DESC 

select * from [myebankLOGDB].[dbo].[EJ] 
where URI ='/ebankC/res/sc021102001'
order by [DATE] desc


SELECT  * from API where API_ID ='SC050101003'order by 1

SELECT *
  FROM myebankDB.dbo.EJ2HUB
  where HUB_API like 'ws%03'
  order by 5 desc
  
  
  select * from 
  
SELECT * FROM MAPUST WHERE CID = '24829752A' AND UID = 'admin1' AND STATUS != '99'

select * from USERS where CID ='96896912A'

select * from TX_QUEUE where TXQ_CID ='96896912A' order by 3 DESC 

select * from PAYEE where CID ='96896912A' order by CDATE DESC 

select  * from TX t 

select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)where CID ='52570683A'order by INBOUNDTIME DESC
select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)where CLASSNAME =''order by INBOUNDTIME DESC 

select * from TX_QUEUE tq where TXQ_ID =''
select * from TX 

A41T
A51T

AFIS-57S
A5ET


select * from MAP_BANKCODE where
097 0179

--INSERT INTO MAP_BANKCODE
--  ([BRANCHCODE_OLD]
-- ,[BRANCHCODE]
--  )
--  VALUES
-- ('017'
-- ,'0179')
 select * from [MAP_BANKCODE] where BRANCHCODE_OLD='097'
 
 select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)where CID ='52570683A'order by INBOUNDTIME DESC--2024/08/07 10:30:10.232
select * FROM [myebankLOGDB].[dbo].[EJ]WITH(NOLOCK) where CID='52570683A' order by DATE desc

select * from TX_QUEUE tq where TXQ_FCID ='FC20240807095500586'


SELECT * FROM BANKCODE where BANKCODE ='803' ORDER BY BANKCODE, BRANCHCODE--where BANKCODE ='017'
 select * FROM [myebankLOGDB].[dbo].[EJ] WITH(NOLOCK)where URI ='/ebankC/res/sc000201002'order by DATE DESC--2024/08/07 09:48:21.273
 
 
select * from TX_QUEUE
select * from TX where TX_CID ='52570683A' and EAI_TranSeq ='U070000027'
'U070000027'
'U070000030'

 select * FROM [myebankLOGDB].[dbo].[EJ2HUB]WITH(NOLOCK) where HUB_API like '%ZQ952A1%'
 
 Select * from BATCHLIST
 
 select * from myebankLOGDB.dbo.EJ2HUB order by INBOUNDTIME DESC 

 select * from CERTIFICATE where KEEPER ='84742479A'
 
 
 select * from [myebankLOGDB].[dbo].[EJ2HUB] where CLASSNAME = 'SC030501002DO'order by 5 DESC 
 select * from [myebankLOGDB].[dbo].[EJ] where URI = '/ebankC/res/sc030501002'order by 5 DESC 

 
 select * from [myebankLOGDB].[dbo].[EJ2HUB] 
 where HUB_API like '%3030%' 
 --where substring(INBOUNDTIME,1,10)='2024/09/23'
 order by INBOUNDTIME desc --#3732 --2024/09/23 16:53:03.221
 
 
 select * from TX where TX_SID ='SC030501002DO' order by TX_EXEC_EDATE DESC 
 SELECT * FROM TX WHERE TX_SID = 'SC030504002DO' AND TX_CID = '52570683A' AND TX_FCID = 'FC20240806170347440' ORDER BY TX_ORDER ASC, TXSN ASC
 
 
 SELECT TOP (1000) *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  ORDER BY INBOUNDTIME DESC
  
  
 
SELECT TOP (1000) *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  where HUB_API like'%A96F%'
  ORDER BY INBOUNDTIME DESC 
  
  SELECT TOP (1000) *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  --where HUB_API like'%A078%'
  ORDER BY INBOUNDTIME DESC 
  
  SELECT TOP (1000) *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  where HUB_API like'%11U%'
  ORDER BY INBOUNDTIME DESC 
  

  SELECT *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  where CID ='80071033A'
  ORDER BY INBOUNDTIME DESC 
  
  select * from FEE_CONFIG  order by 1 
  
  SELECT  * from CERTIFICATE where KEEPER ='96919464A' and UBKEY_SN ='2014090005'
  
  
  
  
  
  SELECT *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  where CID ='80071033A'
  ORDER BY INBOUNDTIME DESC 
  
  
  
  
  
  
  
  
  
  
  
  select * from FUND_QUEUE order by FUNDQ_RC1_SDATE 
 select * from PROPERTIES_P where P_KEY ='PWD_ERRCOUNT_LIMIT_CHGPWD'
  
  SELECT 
       ec.client_net_address AS ClientIPAddress,
       COUNT(*) AS NumberOfConnections,
       sP.status AS SessionStatus
   FROM 
       sys.dm_exec_connections ec
   JOIN 
       sys.sysprocesses sP ON ec.session_id = sP.spid
   WHERE 
       DB_NAME(sP.dbid) = 'myebankDB'
   GROUP BY 
       ec.client_net_address, sP.status;

      
      
      
      
      
      
select * from TX_QUEUE where TXQ_CID='testA'
      
      SELECT TOP (1000) [BRANCHCODE_OLD]
      ,[BRANCHCODE]
  FROM [myebankDB].[dbo].[MAP_BANKCODE] with (nolock)
  where BRANCHCODE_OLD in('053','097')
      
      
      
      SELECT * from BATCHLIST b 
      
      
      
      
      
      select * from CERTIFICATE where KEEPER ='96919464A'
      

  SELECT * from TX_QUEUE tq where TXQ_SID = 'SC030102002DO'
  


  
  
  SELECT *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  --WHERE  HUB_API ='ZQ952A100v00'--CID = '52570683A'
  ORDER BY INBOUNDTIME DESC

  
SELECT * FROM BANKCODE ORDER BY BANKCODE, BRANCHCODE
  


SELECT * FROM BANKCODE WHERE BANKCODE = '803' ORDER BY BANKCODE, BRANCHCODE





select * from TX_QUEUE where 

select * from SERVICES where SID like '%SC05%'--申、轉、贖、變







select * from SERVICES where SNAME in('基金申購','基金贖回'
,'基金轉換','暫停扣款','恢復扣款'
,'變更每次投資金額','變更扣款帳號','變更每月投資日')

update SERVICES set STATUS ='0' where SNAME='基金申購'
update SERVICES set STATUS ='0' where SNAME='基金贖回'
update SERVICES set STATUS ='0' where SNAME='基金轉換'
update SERVICES set STATUS ='0' where SNAME='暫停扣款'
update SERVICES set STATUS ='0' where SNAME='恢復扣款'
update SERVICES set STATUS ='0' where SNAME='變更每次投資金額'
update SERVICES set STATUS ='0' where SNAME='變更扣款帳號'
update SERVICES set STATUS ='0' where SNAME='變更每月投資日'


select * from [myebankLOGDB].[dbo].[EJ2HUB] where CID ='80071033A' and HUB_API ='ws0000005'order by INBOUNDTIME  DESC 

SELECT
	JSON_VALUE(INBOUND,'$._RecordUuid') as _RecordUuid
	, CID
	, CLASSNAME 
	, HUB_API
	, INBOUNDTIME
	, INBOUND
	, OUTBOUNDTIME 
	, OUTBOUND 
FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
where SUBSTRING(INBOUNDTIME,1,10)='2024/11/01'
and ISJSON(OUTBOUND) > 0 
and ISJSON(INBOUND) > 0 
and JSON_VALUE(OUTBOUND,'$.rc')!='M000' 


SELECT * FROM BANKCODE where BANKCODE in ('612','805')order by 1

SELECT  * from FUND_QUEUE fq  where FUNDQ_CID ='80071033A' order by 7 desc


---
select * from [myebankLOGDB].[dbo].[EJ] where CID ='13001973A' and UID ='admin1'andURI ='/ebankC/res/sc040401006'order by [DATE]  DESC 
---
select * from [myebankLOGDB].[dbo].[EJ2HUB] 
where 
CID ='13001973A' and UID ='admin1'and 
CLASSNAME ='SC040401006'
order by INBOUNDTIME desc
---
select * from [myebankLOGDB].[dbo].[EJ] where CID ='90131361A' and [DATE]  between '2024/10/28' and '2024/10/29'
select * from [myebankLOGDB].[dbo].[EJ2HUB] where CID ='90131361A' and [INBOUNDTIME]  between '2024/10/28' and '2024/10/29'




SELECT *FROM [myebankLOGDB].[dbo].[EJ]with(nolock)where CID='90131361A' order by DATE DESC 
SELECT *FROM [myebankLOGDB].[dbo].[EJ2HUB]with(nolock)where CID='90131361A'and CLASSNAME='SC040401006' order by INBOUNDTIME desc



select * FROM MAPUR WHERE UID like '%[^A-Za-z0-9]%'

select * from API where API_DESC like'%憑證展期%' order by 1

SELECT *FROM [myebankLOGDB].[dbo].[EJ]with(nolock)order by DATE DESC 






SELECT *
  FROM [CERTIFICATE]
  WHERE CertType = '3'
  AND KEEPER = '23357868A'
  AND UBKEY_SN = '2018080001'

SELECT *
  FROM [CERTIFICATE]
  where UBKEY_SN ='8039919901'


SELECT *FROM [myebankLOGDB].[dbo].[EJ]with(nolock) where URI='/ebankC/res/sc050201001' order by DATE DESC 
SELECT *FROM [myebankLOGDB].[dbo].[EJ2HUB]with(nolock) where CID='13001973A' order by INBOUNDTIME desc

select * from MAIL_TEMPLATE
SELECT *FROM [myebankLOGDB].[dbo].[EJ2HUB]with(nolock) where CID='13001973A' and HUB_API='cert000008' order by INBOUNDTIME desc


select * from BATCHLIST

SELECT *FROM [myebankLOGDB].[dbo].[EJ2HUB]with(nolock) where CID='76240923A' order by INBOUNDTIME desc


select * from FUND_QUEUE fq order by FUNDQ_RC1_SDATE DESC 


select * from myebankDB.dbo.TX_QUEUE with(nolock) where TXQ_FCID in ('FC20191218093744180','FC20241120113941125','FC20241120114209705','FC20241120114322200','FC20241120114441053','FC20241120123021245')

select * from [myebankLOGDB].[dbo].[EJ20241028] where URI ='/ebankC/res/sc040401006' order by 5
select * from [myebankLOGDB].[dbo].[EJ2HUB20241028]where CLASSNAME='SC040401006'  order by 5

select * from TX_QUEUE tq order by TXQ_EXEC_ACTUAL_DATE  desc

SELECT *FROM [myebankLOGDB].[dbo].[EJ2HUB]with(nolock) 
where HUB_API='hq01603937' order by 5 desc

SELECT *FROM [myebankLOGDB].[dbo].[EJ]with(nolock) 
where URI='/ebankC/res/sc020202003'
order by 4 desc


---
select *--SUBSTRING(BRANCHCODE,1,3) as 'trueBranchCode' 
from MAP_BANKCODE with(nolock)
where BRANCHCODE_OLD = '053'--由簽端帶入的客戶的帳號前3三碼

--經理人表
select * from BRANCHINFORMATION --053

--整合
select b.ADDRESS ,b.BRANCHCODE , b.BRANCHNAME ,b.MANAGER 
from MAP_BANKCODE a with(nolock)
INNER JOIN BRANCHINFORMATION b
on SUBSTRING(a.BRANCHCODE,1,3) = b.BRANCHCODE 
where BRANCHCODE_OLD = '053'--由簽端帶入的客戶的帳號前3三碼



select * from PROPERTIES_U pu where P_KEY in('F_TYPE_DATE','F_EX_TYPE_DATA','F_SINGLE_TYPE_DATA')

SELECT *
  FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
  WHERE CID = '68779195A' and HUB_API ='hq00605038' order by INBOUNDTIME desc
  
  
  SELECT *
  FROM [myebankLOGDB].[dbo].[EJ] WITH(NOLOCK) order by [DATE]  DESC 
  
  select * from API a 
  
	select * from SERVICES where SID in ('SC03-03-010','SC03-08-010','SC03-08-020','SC02-06-050') 
	--SC03-03-010--外幣匯入匯款線上解匯
	
	--SC03-08-010--線上開狀申請
	--SC03-08-020--線上開狀申請狀態查詢
	
	--SC02-06-050--海外ETF
	
	select * from TX_QUEUE order by 7 desc
	
	select * from API where API_NAME like'%信用卡%'
	
	select * from myebankLOGDB.dbo.EJ2HUB order by 5 DESC 
	
	select * from myebankLOGDB.dbo.EJ with(nolock)
	
	---
	with temp as ()
	---

	select 
		CASE 
			WHEN URI = '/ebankC/res/sc021101001' THEN '總次數：信用卡總覽'
			WHEN URI = '/ebankC/res/sc021102001' THEN '總次數：帳單明細查詢'
			WHEN URI = '/ebankC/res/sc021103001' THEN '總次數：未出帳明細查詢'
		END transactionName
		, substring([DATE],1,7)as date 
		, count(substring([DATE],1,7)) as count 
	from myebankLOGDB.dbo.EJ with(nolock)
	where
		URI in ('/ebankC/res/sc021101001','/ebankC/res/sc021102001','/ebankC/res/sc021103001')
		and substring([DATE],1,7) in ('2024/07','2024/08','2024/09','2024/10','2024/11')
	GROUP by substring([DATE],1,7),URI
	order by date
	
	--- 一個統編算一個月算一次
with temp as (
	select 
		CASE 
			WHEN URI = '/ebankC/res/sc021101001' THEN '歸戶次數：信用卡總覽'
			WHEN URI = '/ebankC/res/sc021102001' THEN '歸戶次數：帳單明細查詢'
			WHEN URI = '/ebankC/res/sc021103001' THEN '歸戶次數：未出帳明細查詢'
		END transactionName
		, substring([DATE],1,7)as date 
		, count(CID) as count 
		,CID
	from myebankLOGDB.dbo.EJ with(nolock)
	where
		URI in ('/ebankC/res/sc021101001','/ebankC/res/sc021102001','/ebankC/res/sc021103001')
		and substring([DATE],1,7) in ('2024/07','2024/08','2024/09','2024/10','2024/11')
	GROUP by substring([DATE],1,7),URI,CID
	--order by date,CID
) 
select 
	transactionName
	,date
	,count(CID) as count
from temp with(nolock)
group by transactionName,date
order by date
	---
	
	select * from [myebankLOGDB].[dbo].[EJ] with(nolock)
	where ISJSON(JSONSTR) > 0 
	and (JSON_VALUE(JSONSTR,'$.rc')='M9907' or JSON_VALUE(JSONSTR,'$.rc2')='M9907')
	order by DATE DESC
	
	---
	
select JSON_VALUE(OUTBOUND,'$.result.data.fisc_rspcode'),*--, CID, UID ,CLASSNAME ,INBOUNDTIME 
FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
where HUB_API = 'Communicate/getatmpEAI'
and JSON_VALUE(OUTBOUND,'$.result.data.fisc_rspcode')!='4001'
order by INBOUNDTIME DESC

	---
	
SELECT JSON_VALUE(EAI_OUTBOUND,'$.result.data.fisc_rspcode'),* from [myebankDB].[dbo].[TX] with(nolock) where SUBSTRING(TX_EXEC_SDATE,1,10) ='2024/12/10' and EAI_API = 'Communicate/getatmpEAI' and JSON_VALUE(EAI_OUTBOUND,'$.result.data.fisc_rspcode')!='4001'
order by TX_EXEC_SDATE DESC 


select *from ETF_QUEUE where ETFQ_FCID ='FC20241213090307429'

select * from [myebankLOGDB].[dbo].[EJ] with(nolock)
	where CID ='16402655A' and URI ='/ebankC/res/sc050502003'
	order by DATE DESC
	
select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
where CID ='16402655A' 
	and ISJSON(OUTBOUND) > 0 
	and JSON_VALUE(OUTBOUND,'$.rc2')='IIA0C'--'IIB0E'
	--and JSON_VALUE(OUTBOUND,'$.result.data.fisc_rspcode')!='4001'
order by INBOUNDTIME DESC

select * FROM [myebankLOGDB].[dbo].[EJ2HUB]
--
select 
	SUBSTRING(CLASSNAME,1,11)
	, a.API_NAME 
	, HUB_API
FROM [myebankLOGDB].[dbo].[EJ2HUB] as b WITH(NOLOCK)
left join API a on SUBSTRING(b.CLASSNAME,1,11) = a.API_ID 
where (HUB_API like 'kyc%' or HUB_API like 'KYC%')
GROUP by SUBSTRING(CLASSNAME,1,11), a.API_NAME , HUB_API
--

select SUBSTRING(CLASSNAME,1,11) , HUB_API
FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
where HUB_API like 'kyc%' or HUB_API like 'KYC%'
GROUP by SUBSTRING(CLASSNAME,1,11) , HUB_API

--
select * from TOKEN_ALL ta 


sELECT * FROM CUSTOMER WHERE CID = '16402655A' AND STATUS != '99'

SELECT * FROM USERS WHERE CID = '16402655A'AND UID = 'admin1' AND STATUS != '99'

SELECT  * from EJ2HUB eh 

SELECT * FROM sys.sequences

select * from API a 

select * from SERVICES order by 1 --where SID  like'SC05%'

---業檔
UPDATE BRANCHINFORMATION SET MANAGER = '魏趨師' where BRANCHCODE ='006'
UPDATE BRANCHINFORMATION SET MANAGER = '陳建州' where BRANCHCODE ='059'
UPDATE BRANCHINFORMATION SET MANAGER = '歐怡和' where BRANCHCODE ='060'
UPDATE BRANCHINFORMATION SET MANAGER = '張俊堂' where BRANCHCODE ='086'
UPDATE BRANCHINFORMATION SET MANAGER = '周國光' where BRANCHCODE ='087'
UPDATE BRANCHINFORMATION SET MANAGER = '蔡瑞麟' where BRANCHCODE ='088'
select * from BRANCHINFORMATION where BRANCHCODE in('006','059','060','086','087','088')



select * from TX_QUEUE tq  where TXQ_SID in ('SC030101002DO')
se0lect * from TX_QUEUE tq  where TXQ_SID in ('SC030102002DO')
select * from TX_QUEUE tq  where TXQ_SID in ('SC030506002DO')







select * from FLOWSIGN f 

select * from TOKEN_ALL ta 


select * FROM [myebankDB].[dbo].[ETF_QUEUE] 
-----
select 
	SUBSTRING(ETFQ_EXEC_DATE,1,7) as '日期'
	, COUNT(*) as 筆數 ,Currency as 幣別 
	, SUM(TRY_CAST(EntruRecAMT AS decimal(20, 2))) as '委託應收付金額'
FROM [myebankDB].[dbo].[ETF_QUEUE]
WHERE ETFQ_EXEC_DATE BETWEEN '2023/01/00' AND '2023/07/18'
 	AND ETFQ_SID = 'SC050501003DO'
	AND TRY_CAST(EntruRecAMT AS decimal(20, 2))  > 1.00
	and ETFQ_SID in ('SC050501003DO','SC050502003DO','SC050503002DO')
	and ETFQ_RC1 in ('T55131','T55231','T55321')
GROUP BY SUBSTRING(ETFQ_EXEC_DATE,1,7) ,Currency 
ORDER BY SUBSTRING(ETFQ_EXEC_DATE,1,7) desc;
------------客戶數
select 
	SUBSTRING(ETFQ_EXEC_DATE,1,7) as '日期'
	, ETFQ_CID as '統編'
	, COUNT(ETFQ_CID) as 筆數
	--, SUM(TRY_CAST(EntruRecAMT AS decimal(20, 2))) as '委託應收付金額'
FROM [myebankDB].[dbo].[ETF_QUEUE]
WHERE ETFQ_EXEC_DATE BETWEEN '2023/01/00' AND '2023/07/18'
	--AND TRY_CAST(EntruRecAMT AS decimal(20, 2))  > 1.00
	and ETFQ_SID in ('SC050501003DO','SC050502003DO','SC050503002DO')
	and ETFQ_RC1 in ('T55131','T55231','T55321')
GROUP BY SUBSTRING(ETFQ_EXEC_DATE,1,7) ,ETFQ_CID 
ORDER BY SUBSTRING(ETFQ_EXEC_DATE,1,7) desc;
------------


select ETFQ_EXEC_DATE , COUNT(*) as 配息入帳帳號變更成功筆數  
FROM [myebankDB].[dbo].[ETF_QUEUE]
WHERE ETFQ_EXEC_DATE BETWEEN '2023/01/01' AND '2023/07/18'
	 AND ETFQ_SID = 'SC050504002DO'
GROUP BY ETFQ_EXEC_DATE 
ORDER BY ETFQ_EXEC_DATE desc;















SELECT 
	CASE 
		WHEN ETFQ_SID = 'SC050501003DO' THEN '委託買進成功'
		WHEN ETFQ_SID = 'SC050502003DO' THEN '委託賣出成功'
		WHEN ETFQ_SID = 'SC050503002DO' THEN '委託取消成功'
	END '交易類型',
SUBSTRING(ETFQ_EXEC_DATE,1,7) AS ETFQ_EXEC_DATE  , 
COUNT(*) as 筆數 ,Currency as 幣別 ,SUM(TRY_CAST(EntruRecAMT AS decimal(20, 2))) as '委託應收付金額'
FROM [myebankDB].[dbo].[ETF_QUEUE] with (nolock)
WHERE 
 ETFQ_SID IN ('SC050501003DO', 'SC050502003DO', 'SC050503002DO')
 AND ETFQ_RC1 IN('T55131','T55231','T55321')
 AND TRY_CAST(EntruRecAMT AS decimal(20, 2))  > 1.00
GROUP BY  ETFQ_SID, SUBSTRING(ETFQ_EXEC_DATE,1,7) ,Currency 
ORDER BY SUBSTRING(ETFQ_EXEC_DATE,1,7)  asc;






select * from EJ2HUB with(nolock) where CID ='13001973A' order by 5 DESC 
select * from EJ where URI like '%040204001' order by [DATE]  desc




SELECT MAX (TXQ_EXEC_DATE) AS 'date', MAX (PayId) AS 'cid', LEFT(PayAccount, 3) AS 'branchCode', SUM(CAST(PayAmount AS BIGINT)) AS 'totalAmt' FROM ( SELECT TXQ_SID , TXQ_EXEC_DATE , CASE WHEN TXQ_SID ='SC030101002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranData') WHEN TXQ_SID ='SC030102002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranDataList') END as datas FROM TX_QUEUE as T with(nolock) LEFT JOIN FLOWSCONTROL AS F with (nolock) ON F.FCID = T.TXQ_FCID WHERE TXQ_SID IN('SC030101002DO','SC030102002DO') AND TXQ_STATUS = '0' AND ISJSON(F.DO_JSON) > 0 AND TXQ_EXEC_DATE = '2025/03/01' ) AS temp CROSS APPLY OPENJSON(datas) WITH (BankCode       nvarchar(max) '$.BankCode', PayId          nvarchar(max) '$.PayId', PayAccount	   nvarchar(max) '$.PayAccount', PayAmount      nvarchar(max) '$.PayAmount') WHERE BankCode <> '803' GROUP BY TXQ_EXEC_DATE, PayId, LEFT(PayAccount, 3) 
SELECT MAX (TXQ_EXEC_DATE) AS 'date', MAX (PayId) AS 'cid', LEFT(PayAccount, 3) AS 'branchCode', SUM(CAST(PayAmount AS BIGINT)) AS 'totalAmt' FROM ( SELECT TXQ_SID , TXQ_EXEC_DATE , CASE WHEN TXQ_SID ='SC030101002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranData') WHEN TXQ_SID ='SC030102002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranDataList') END as datas FROM TX_QUEUE as T with(nolock) LEFT JOIN FLOWSCONTROL AS F with (nolock) ON F.FCID = T.TXQ_FCID WHERE TXQ_SID IN('SC030101002DO','SC030102002DO') AND TXQ_STATUS = '0' AND ISJSON(F.DO_JSON) > 0 AND TXQ_EXEC_DATE = '2025/03/20' ) AS temp CROSS APPLY OPENJSON(datas) WITH (BankCode       nvarchar(max) '$.BankCode', PayId          nvarchar(max) '$.PayId', PayAccount	   nvarchar(max) '$.PayAccount', PayAmount      nvarchar(max) '$.PayAmount') WHERE BankCode <> '803' GROUP BY TXQ_EXEC_DATE, PayId, LEFT(PayAccount, 3) 
SELECT MAX (TXQ_EXEC_DATE) AS 'date', MAX (PayId) AS 'cid', LEFT(PayAccount, 3) AS 'branchCode', SUM(CAST(PayAmount AS BIGINT)) AS 'totalAmt' FROM ( SELECT TXQ_SID , TXQ_EXEC_DATE , CASE WHEN TXQ_SID ='SC030101002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranData') WHEN TXQ_SID ='SC030102002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranDataList') END as datas FROM TX_QUEUE as T with(nolock) LEFT JOIN FLOWSCONTROL AS F with (nolock) ON F.FCID = T.TXQ_FCID WHERE TXQ_SID IN('SC030101002DO','SC030102002DO') AND TXQ_STATUS = '0' AND ISJSON(F.DO_JSON) > 0 AND TXQ_EXEC_DATE = '2025/03/21' ) AS temp CROSS APPLY OPENJSON(datas) WITH (BankCode       nvarchar(max) '$.BankCode', PayId          nvarchar(max) '$.PayId', PayAccount	   nvarchar(max) '$.PayAccount', PayAmount      nvarchar(max) '$.PayAmount') WHERE BankCode <> '803' GROUP BY TXQ_EXEC_DATE, PayId, LEFT(PayAccount, 3) 
SELECT MAX (TXQ_EXEC_DATE) AS 'date', MAX (PayId) AS 'cid', LEFT(PayAccount, 3) AS 'branchCode', SUM(CAST(PayAmount AS BIGINT)) AS 'totalAmt' FROM ( SELECT TXQ_SID , TXQ_EXEC_DATE , CASE WHEN TXQ_SID ='SC030101002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranData') WHEN TXQ_SID ='SC030102002DO' THEN JSON_QUERY(F.DO_JSON,'$.data.tranDataList') END as datas FROM TX_QUEUE as T with(nolock) LEFT JOIN FLOWSCONTROL AS F with (nolock) ON F.FCID = T.TXQ_FCID WHERE TXQ_SID IN('SC030101002DO','SC030102002DO') AND TXQ_STATUS = '0' AND ISJSON(F.DO_JSON) > 0 AND TXQ_EXEC_DATE = '2025/03/22' ) AS temp CROSS APPLY OPENJSON(datas) WITH (BankCode       nvarchar(max) '$.BankCode', PayId          nvarchar(max) '$.PayId', PayAccount	   nvarchar(max) '$.PayAccount', PayAmount      nvarchar(max) '$.PayAmount') WHERE BankCode <> '803' GROUP BY TXQ_EXEC_DATE, PayId, LEFT(PayAccount, 3) 

select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)--2025/03/12 15:26:34.111
--where HUB_API ='FX00FILEUP'
where CID ='20081965A' and substring(INBOUNDTIME,1,10)='2025/03/31' 
order by INBOUNDTIME desc

select * from LOC_QUEUE --where LOCQ_FCID ='FC20250312152632830'
where LOCQ_EXEC_DATE ='2025/04/01'
order by 4 desc

--2025/04/07 11:53:48.520
select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
--where CLASSNAME ='SC030801002DO' and CID ='23285582A' and substring(INBOUNDTIME,1,10)='2025/04/01' 
--where CLASSNAME ='E2EE0000E1'
--where CID ='23285582A'
--where SUBSTRING(INBOUNDTIME,1,13)='2025/04/07 11' --2025/04/07 11:53:48.520
where HUB_API like'%SMS%'
order by INBOUNDTIME desc


select * from PROPERTIES_P where P_KEY in('SMS_ID','SMS_PWD')
select * from PROPERTIES_T where P_KEY in('SMS_ID','SMS_PWD')
select * from PROPERTIES_U where P_KEY in('SMS_ID','SMS_PWD')

select * from USERS where CID ='84742479A'

SELECT  * from MAIL_TEMPLATE where MT_ID ='RmtRefund2'

select 
CID as '統編'
,UID as '使用者' 
--,CLASSNAME 
,CASE
	WHEN CLASSNAME = 'SC000102001' THEN 'ADMIN取得首登密碼'
	WHEN CLASSNAME = 'NoticeControl' THEN '退匯通知'
END 交易名稱
,HUB_API as '電文'
,INBOUNDTIME  as '送去主機電文時間'
,INBOUND  as '主機電文上行'
,OUTBOUNDTIME  as '主機電文回傳時間'
,OUTBOUND  as '主機回傳'
FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK)
where HUB_API like'%SMS%'
order by INBOUNDTIME desc

SELECT * from PROPERTIES_U pu where P_KEY like'%SMS%'
SELECT * from PROPERTIES_U pu where P_KEY in ('HUBService_URL','')
--https://172.16.45.135:443/EaiHub/resources/


select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK) 
--where HUB_API  like '%SMS%'
where CID ='84801906A'--2025/04/14 16:32:30.142
order by INBOUNDTIME DESC 

select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK) 
where HUB_API  like '%sms%'
order by INBOUNDTIME DESC 


select * FROM [myebankLOGDB].[dbo].[EJ] WITH(NOLOCK) 
--where HUB_API  like '%SMS%'
where URI like '%000102001%'--2025/04/14 16:32:30.142
and CID ='84801906A'
order by [DATE] DESC 

SELECT * FROM USERS 
WHERE 
--CID='84801906A' 
--AND LOGINID='admin1' 
--AND MOBILE=? 
--AND UPPER(EMAIL)=? 
ISADMIN='1' 
AND PASSDATE='' 
AND LOGINDATE='' 
AND STATUS in ('01')

SELECT * FROM PROPERTIES_U pu 


select * from USERS u2 where CID ='01166680A' and UID ='admin1'
--01166680A --admin1

select * from PROPERTIES_P where P_KEY like'SMS%'
--INSERT INTO [dbo].[PROPERTIES_P]([P_KEY],[P_VALUE],[P_DESC])VALUES('EAI_URI_SMS', 'SMSCommon3','EAI_HUB')
--INSERT INTO [dbo].[PROPERTIES_U]([P_KEY],[P_VALUE],[P_DESC])VALUES('EAI_URI_SMS', 'SMSCommon3','EAI_HUB')
--INSERT INTO [dbo].[PROPERTIES_T]([P_KEY],[P_VALUE],[P_DESC])VALUES('EAI_URI_SMS', 'SMSCommon3','EAI_HUB')


select * from [myebankLOGDB].[dbo].[EJ2HUB] with(nolock) 
where CID ='28672078A' and substring(INBOUNDTIME,1,10) ='2025/04/18' 
and HUB_API !='nm00000001'
order by 5 DESC


select * from TaxReturn
where CID ='28672078A'
and NOWDATE ='2025/04/18' 
and API like'%A5ET%'
and TxnSpSeq like '%424100%' or TxnSpSeq like '%4106%'
order by CDATE desc

select * from API a  where API_ID ='SC000103001'


select * from [myebankLOGDB].[dbo].[EJ2HUB] with(nolock) 
order by 5 DESC


select * from [myebankLOGDB].[dbo].[EJ] with(nolock) 
order by 4 DESC

select * from TX_QUEUE order by TXQ_EXEC_ACTUAL_DATE desc

select * from BATCHLIST b --

select * from TX_QUEUE where TXQ_SID ='SC030102002DO'order by 3 DESC 

select * from CERTIFICATE c 

select * from API a 

select * from USERS u where CID ='84742479A'

select * from BANKCODE where BANKCODE ='009' and BRANCHCODE =''

select * from TX 
where --PAYER_ACC ='027100019561' and
TX_SID in('SC030101002DO','SC030102002DO')
order by TX_EXEC_EDATE DESC

select * from BATCHLIST b where BID ='B016'

select * from BATCHLIST WHERE BID = 'B016'

select * from TX_QUEUE tq where TXQ_RC1_Count != TXQ_RC1_TotalCount

UPDATE  BATCHLIST  SET BTIME = '17:00', RUNDATE =''  WHERE BID = 'B016'

SELECT * FROM BANKCODE WHERE BANKCODE = '0011' AND BRANCHCODE LIKE '0011%'

SELECT * FROM BANKCODE WHERE 
BANKCODE = '048' AND 
BRANCHCODE LIKE '0011%'

select * from FUND_QUEUE where FUNDQ_FCID ='FC20250820103527410'

select * from ACH_QUEUE aq 

select * from BATCHLIST b 

select * from EJ2HUB where HUB_API like'%075%'order by INBOUNDTIME DESC 

select * from FUND_QUEUE fq order by 7 DESC 

select * from PROPERTIES_P where P_KEY like '%EAI%'

select * from MAIL_TEMPLATE mt where MT_ID ='FUNDB01_B'
select * from PROPERTIES_P where P_KEY ='A038_Flg3'
select * from FTP_REMIT


select * from API order by 1 


  select * from SERVICES where SID in ('SC02-07-060','SC02-07-070')

  
  select * from myebankLOGDB.dbo.EJ where CID ='80071033A'order by [DATE] DESC 
--80071033A	admin0	/ebankC/res/sc050501001	2025/12/19 13:59:43.276	172.16.108.216	{"head":{"Time":"2025/12/19 13:59:43.276"},"rc":"T55114|","msg":"海外ETF/股票-委託買進異常|","token":"735DF1435BB3D81B56FA3378287E700B1D21055CD2F620A8704A9FF6D748BB0E","result":{"UserData":null,"flow":null}}	1		62346


  select * from myebankLOGDB.dbo.EJ2HUB where HUB_API ='EQ00FSTIN010'order by INBOUNDTIME



