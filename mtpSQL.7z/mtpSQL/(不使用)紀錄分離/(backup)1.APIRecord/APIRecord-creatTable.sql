CREATE TABLE APIRecord (
	QID					[nvarchar]	(36)	NOT NULL DEFAULT('')--"Queue編號KEY 9f4493a4-06a3-48a2-8ca4-230510a58605"
	, EXEC_DATE			[nvarchar]	(10)	NOT NULL DEFAULT('')--交易執行日(YYYY/MM/DD)
	, EXEC_ACTUAL_DATE	[nvarchar]	(23)	NOT NULL DEFAULT('')--實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
	, API_SID			[nvarchar]	(10)	NOT NULL DEFAULT('')--API編號
	, API_REQ			[nvarchar]	(MAX)	NOT NULL DEFAULT('')--open api 上行
	, API_RES			[nvarchar]	(MAX)	NOT NULL DEFAULT('')--open api 下行
	, API_STATUS		[nvarchar]	(1)		NOT NULL DEFAULT('')--API狀態(0:未執行，1:完成，2:處理中 )
	, IP				[nvarchar]	(MAX)	NOT NULL DEFAULT('')--來源IP
	, TO_FISC_STATUS	[nvarchar]	(1)		NOT NULL DEFAULT('')--送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗 )若當天不成功3或者是空，要重發至成功為止
	, STATUS			[nvarchar]	(2)		NOT NULL DEFAULT('')--狀態00:正常,99:註銷
	, IN_ACC			[nvarchar]	(20)	NOT NULL DEFAULT('')--轉入行帳號
	, IN_ACC_BANKCODE	[nvarchar]	(10)	NOT NULL DEFAULT('')--轉入行銀行代號
	, OUT_ACC			[nvarchar]	(20)	NOT NULL DEFAULT('')--轉出行帳號
	, OUT_ACC_BANKCODE	[nvarchar]	(10)	NOT NULL DEFAULT('')--轉出行銀行代號
	, SVC_TYPE			[nvarchar]	(10)	NOT NULL DEFAULT('')--"A01(MTP發財金查詢), A02(MTP發財金申請), A03(MTP發財金取消) ；B01(財金發MTP查詢), B02(財金發MTP申請), B03(財金發MTP取消)A: MTP→FISCB: FISC→MTP01:查詢02:申請03:取消"
	, RTN_CODE			[nvarchar]	(10)	NOT NULL DEFAULT('')--財金或主機回傳下行的code
	, FISC_RC			[nvarchar]	(10)	NOT NULL DEFAULT('')--財金約定帳號通報結果
)
