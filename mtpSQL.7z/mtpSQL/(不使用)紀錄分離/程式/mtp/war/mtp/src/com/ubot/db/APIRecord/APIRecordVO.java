package com.ubot.db.APIRecord;

import com.fasterxml.jackson.annotation.JsonValue;
import com.ubot.tools.common.JsonTool;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class APIRecordVO {
    public APIRecordVO(HttpServletRequest request) {
        this.IP = request.getRemoteAddr();
        this.API_SID = request.getPathInfo().substring(1);
    }

    @AllArgsConstructor
    public enum SVC_TYPE {
        A01		("A01" , "MTP發財金查詢")
        , A02	("A02" , "MTP發財金申請")
        , A03	("A03" , "MTP發財金取消")

        , B01	("B01" , "財金發MTP查詢")
        , B02	("B02" , "財金發MTP申請")
        , B03	("B03" , "財金發MTP取消")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
    }
    @AllArgsConstructor
    public enum API_STATUS {
        INIT		("0" , "未執行")
        , FINISH	("1" , "完成")
        , PROCESS	("2" , "處理中")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
    }
    @AllArgsConstructor
    public enum STATUS {
        OK		("00" , "正常")
        , CANCEL	("99" , "註銷")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
    }

    private String QID	            ="";//nvarchar			36	‘’		"Queue編號KEY 9f4493a4-06a3-48a2-8ca4-230510a58605"
    private String EXEC_DATE	    ="";//nvarchar			10	‘’		交易執行日(YYYY/MM/DD)
    private String EXEC_ACTUAL_DATE	="";//nvarchar			23	‘’		實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
    private String API_SID	        ="";//nvarchar			10	‘’		API編號
    private String API_REQ	        ="";//nvarchar			MAX	‘’		open api 上行
    private String API_RES	        ="";//nvarchar			MAX	‘’		open api 下行
    private String API_STATUS	    ="";//nvarchar			1	‘’		API狀態(0:未執行，1:完成，2:處理中 )
    private String IP	            ="";//nvarchar			MAX	‘’		來源IP
    private String TO_FISC_STATUS	="";//nvarchar			1	‘’		送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗 )若當天不成功3或者是空，要重發至成功為止
    private String STATUS	        ="";//nvarchar			2	‘’		狀態00:正常,99:註銷
    private String IN_ACC	        ="";//nvarchar			20	‘’		轉入行帳號
    private String IN_ACC_BANKCODE	="";//nvarchar			10	‘’		轉入行銀行代號
    private String OUT_ACC	        ="";//nvarchar			20	‘’		轉出行帳號
    private String OUT_ACC_BANKCODE	="";//nvarchar			10	‘’		轉出行銀行代號
    private String SVC_TYPE	        ="";//nvarchar			10	‘’		"A01(MTP發財金查詢), A02(MTP發財金申請), A03(MTP發財金取消) ；B01(財金發MTP查詢), B02(財金發MTP申請), B03(財金發MTP取消)A: MTP→FISC B: FISC→MTP01:查詢02:申請03:取消"
    private String RTN_CODE	        ="";//nvarchar			10	‘’		財金或主機回傳下行的code
    private String FISC_RC          ="";

    @AllArgsConstructor
    public enum TO_FISC_STATUS{
        INIT		("0" , "未執行")
        , FINISH	("1" , "完成")
        , PROCESS	("2" , "處理中")
        , FAIL	    ("3" , "失敗")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
    }
    @AllArgsConstructor
    public enum FISC_RC{//財金下行回覆，財金約定帳號通報結果
        OK                 ("01"    ,"通報完成")
        ,NonAcc             ("02"    ,"非本次規劃帳號")
        ,NoSuchAcc          ("03"    ,"無此帳號")
        ,RepeatNotify       ("04"    ,"重複通報")
        ,NoSuchChannel      ("05"    ,"無此交易通路")
        ,CheckNoAccount     ("06"    ,"查無原約定帳號申請通報交易")
        ,AbnormalAcc        ("07"    ,"帳戶狀態異常")
        ,FAIL               ("A0001" ,"通報失敗")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
        public static FISC_RC find(String val) {
            return Arrays.stream(values())
                    .filter(predicate
                            -> 	predicate.code.equals(val)
                            ||	predicate.content.equals(val))
                    .findFirst()
                    .orElse(null);
        }
    }
    public static String encodeFormSQL(String s) {return s != null && !s.isEmpty() ? s : "";}

    @Override
    public String toString() {return JsonTool.format2Json(this);}
}
