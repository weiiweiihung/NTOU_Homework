package com.ubot.db.APIRecord;

import com.ubot.openapi.mtp2fisc.greylist.Mtp2fiscTool;
import com.ubot.tools.common.Common;
import com.ubot.tools.common.UniqueUtils;
import lombok.extern.log4j.Log4j;

@Log4j
public class APIRecordTool {

    /** 對於財金電文response，存入DB欄位的的統一規則 */
    public static void unifiedFISCFlag(APIRecordVO vo, String fiscCode){
log.debug("***fiscCode:"+fiscCode);
        if(fiscCode.equals(APIRecordVO.FISC_RC.OK.getCode())) //通報成功
            vo.setTO_FISC_STATUS(APIRecordVO.TO_FISC_STATUS.FINISH.getCode());//送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗)若當天不成功要重發至成功為止
        else
            vo.setTO_FISC_STATUS(APIRecordVO.TO_FISC_STATUS.FAIL.getCode());
    }

    public static void dbAction(APIRecordVO.API_STATUS apiStatus, APIRecordVO vo) throws Exception {
        APIRecordDAO daoGLT = new APIRecordDAO();
        if(apiStatus.getCode().equals(APIRecordVO.API_STATUS.INIT.getCode()))
            if(daoGLT.insert(vo)!=1)
                throw new Exception(APIRecordVO.API_STATUS.INIT + Common.INSERT_FAILED);
        if(apiStatus.getCode().equals(APIRecordVO.API_STATUS.PROCESS.getCode()))
            if(daoGLT.updatePROCESS(vo)!=1)
                throw new Exception(APIRecordVO.API_STATUS.PROCESS + Common.UPDATE_FAILED);
        if(apiStatus.getCode().equals(APIRecordVO.API_STATUS.FINISH.getCode()))
            if(daoGLT.updateFINISH(vo)!=1)
                throw new Exception(APIRecordVO.API_STATUS.FINISH + Common.UPDATE_FAILED);
    }
    public static void setCommonINIT(APIRecordVO vo){
        vo.setEXEC_DATE(UniqueUtils.getDate());//交易執行日(YYYY/MM/DD)
        vo.setEXEC_ACTUAL_DATE(UniqueUtils.getDateTime());//實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
        vo.setAPI_STATUS(APIRecordVO.API_STATUS.INIT.getCode());//API狀態(0:未執行，1:完成，2:處理中 )
        vo.setSTATUS(APIRecordVO.STATUS.OK.getCode());//狀態00:正常,99:註銷
//        vo.setAPI_SID(txnvo.getTxn().substring(1));//API編號
//        vo.setCOMEFROM(txnvo.getIp());//來源IP

        if(!Mtp2fiscTool.isUBOT(vo.getIN_ACC_BANKCODE()))
            vo.setTO_FISC_STATUS(APIRecordVO.TO_FISC_STATUS.INIT.getCode());	//送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗 )若當天不成功要重發至成功為止
    }
    public static void setCommonPROCESS(APIRecordVO vo){
        vo.setAPI_STATUS(APIRecordVO.API_STATUS.PROCESS.getCode());//API狀態(0:未執行，1:完成，2:處理中 )

        if(Mtp2fiscTool.isUBOT(vo.getOUT_ACC_BANKCODE())
                && !Mtp2fiscTool.isUBOT(vo.getIN_ACC_BANKCODE()))//mtp->fisc。轉出行(交易發動行)為自行，轉入行為對方=>發財金
            vo.setTO_FISC_STATUS(APIRecordVO.TO_FISC_STATUS.PROCESS.getCode());	//送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗 )若當天不成功要重發至成功為止
    }
    public static void setCommonFINISH(APIRecordVO vo){
        vo.setAPI_STATUS(APIRecordVO.API_STATUS.FINISH.getCode());//API狀態(0:未執行，1:完成，2:處理中 )
    }
}
