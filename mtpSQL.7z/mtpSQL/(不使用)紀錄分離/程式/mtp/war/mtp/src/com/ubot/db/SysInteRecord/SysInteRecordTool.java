package com.ubot.db.SysInteRecord;

import com.ubot.db.vo.EastCallVo;
import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.tools.common.Common;
import com.ubot.tools.common.UniqueUtils;
import lombok.extern.log4j.Log4j;

@Log4j
public class SysInteRecordTool {

//    /** 對於財金電文response，存入DB欄位的的統一規則 */
//    public static void unifiedFISCFlag(SysInteRecordVO vo, String fiscCode){
//log.debug("***fiscCode:"+fiscCode);
//        if(fiscCode.equals(SysInteRecordVO.FISC_RC.OK.getCode())) //通報成功
//            vo.setTO_FISC_STATUS(SysInteRecordVO.TO_FISC_STATUS.FINISH.getCode());//送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗)若當天不成功要重發至成功為止
//        else
//            vo.setTO_FISC_STATUS(SysInteRecordVO.TO_FISC_STATUS.FAIL.getCode());
//    }

    public static void dbAction(SysInteRecordVO.SYSINTE_STATUS apiStatus, SysInteRecordVO vo) throws Exception {
        SysInteRecordDAO daoGLT = new SysInteRecordDAO();
        if(apiStatus.getCode().equals(SysInteRecordVO.SYSINTE_STATUS.INIT.getCode()))
            if(daoGLT.insert(vo)!=1)
                throw new Exception(SysInteRecordVO.SYSINTE_STATUS.INIT + Common.INSERT_FAILED);
        if(apiStatus.getCode().equals(SysInteRecordVO.SYSINTE_STATUS.FINISH.getCode()))
            if(daoGLT.updateFINISH(vo)!=1)
                throw new Exception(SysInteRecordVO.SYSINTE_STATUS.FINISH + Common.UPDATE_FAILED);
    }
    public static void setCommonINIT(
            SysInteRecordVO vo
            , String uuid
            , String req
            , String stan
            , EastCallVo newVO){
        vo.setEXEC_DATE	        (UniqueUtils.getDate    ());
        vo.setEXEC_ACTUAL_DATE	    (UniqueUtils.getDateTime());
        vo.setQID	                (uuid);
        vo.setFISC_URL	            (newVO.getUrl());
        vo.setFISC_REQ	            (req);
        vo.setSTAN	                (stan);
//        vo.setMF_REQ	            (voSysInteRecord.getMF_REQ	            ());
        vo.setSYSINTE_STATUS	    (SysInteRecordVO.TO_FISC_STATUS.INIT.getCode());
    }
    public static void setCommonFINISH(SysInteRecordVO vo, IntegratModel model){
        vo.setFISC_RES	(model.body.toString());//nvarchar			MAX	‘’		財金/主機 下行
        vo.setFISC_RC	(model.originRc);//nvarchar			10	‘’		"財金約定帳號通報結果 01:通報完成 02:非本次規劃帳號 03:無此帳號 04:重複通報 05:無此交易通路 06:查無原約定帳號申請通報交易 07:帳戶狀態異常 A0001:通報失敗"
//        vo.setRETRY_DAY	(vo.getRETRY_DAY	());//nvarchar			23	‘’		重發財金的時間(YYYY/MM/DD HH:MM:SS.SSS)
//        vo.setRETRY_REQ	(vo.getRETRY_REQ	());//nvarchar			MAX	‘’		重發財金的上行
//        vo.setRETRY_RES	(vo.getRETRY_RES	());//nvarchar			MAX	‘’		重發財金的下行
        vo.setRTN_CODE	(vo.getRTN_CODE	    ());//nvarchar			10	‘’		財金或主機回傳下行的code
//        vo.setMF_RES	(vo.getMF_RES	    ());//nvarchar			MAX	‘’		主機下行
        vo.setSYSINTE_STATUS(SysInteRecordVO.SYSINTE_STATUS.FINISH.getCode());//API狀態(0:未執行，1:完成，2:處理中 )
    }
}
