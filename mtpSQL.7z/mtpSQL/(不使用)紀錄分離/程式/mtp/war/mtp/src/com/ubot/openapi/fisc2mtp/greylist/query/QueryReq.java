package com.ubot.openapi.fisc2mtp.greylist.query;

import com.ubot.db.SysInteRecord.SysInteRecordVO;
import com.ubot.openapi.OpenAPICommon;
import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.tools.common.JsonTool;
import com.ubot.tools.common.RegexpUtils;
import lombok.Data;

import static com.ubot.tools.common.RegexpUtils.*;

@Data
public class QueryReq {
    private String account  = "";//string(必填)約定帳號，長度16碼，格式為數字，若不足16碼請右靠左補0

    public static boolean checkReq(QueryReq req, IntegratModel res, SysInteRecordVO voFiscRecord){
        final String sMID = OpenAPICommon.RC.FISC_A0001.getMid();
        if(!RegexpUtils.LENGTH_16.matcher(req.account).matches()){
            res.rc  = sMID;
            res.msg = STR_ACC + LENGTH_16_MSG;
            return false;
        }
        if(!RegexpUtils.E_NUM_7.matcher(voFiscRecord.getFISC_STAN()).matches()){
            res.rc  = sMID;
            res.msg = STR_SEQ + E_NUM_7_MSG;
            return false;
        }
        if(!RegexpUtils.LENGTH_7.matcher(voFiscRecord.getFISC_DESTINATIONID()).matches()){
            res.rc  = sMID;
            res.msg = STR_BANKCODE + LENGTH_7_MSG;
            return false;
        }
        if(!RegexpUtils.LENGTH_7.matcher(voFiscRecord.getFISC_SOURCEID()).matches()){
            res.rc  = sMID;
            res.msg = STR_BANKCODE + LENGTH_7_MSG;
            return false;
        }
        if(!RegexpUtils.LENGTH_14.matcher(voFiscRecord.getFISC_TXNINITDATETIME()).matches()){
            res.rc  = sMID;
            res.msg = STR_DATETIME + LENGTH_14_MSG;
            return false;
        }

        return true;
    }

    @Override
    public String toString() {return JsonTool.format2Json(this);}
}
