package com.ubot.db.SysInteRecord;

import com.ubot.db.ConnectControl;
import com.ubot.tools.common.Common;
import lombok.extern.log4j.Log4j;

import java.sql.PreparedStatement;

@Log4j
public class SysInteRecordDAO extends ConnectControl {
    final String TABLE_FiscRecord	       ="FiscRecord";           //nvarchar			36	‘’		"Queue編號KEY 9f4493a4-06a3-48a2-8ca4-230510a58605"

    final String COL_QID	                ="QID";                 //nvarchar			36	‘’		"Queue編號KEY 9f4493a4-06a3-48a2-8ca4-230510a58605"
    final String COL_EXEC_DATE	            ="EXEC_DATE";           //nvarchar			10	‘’		交易執行日(YYYY/MM/DD)
    final String COL_EXEC_ACTUAL_DATE	    ="EXEC_ACTUAL_DATE";    //nvarchar			23	‘’		實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
    final String COL_API_SID	            ="API_SID";             //nvarchar			10	‘’		API編號
    final String COL_FISC_URL	            ="FISC_URL";            //nvarchar			MAX	‘’		"財金電文url，例如 https://openapigw.fisc-test.com.tw/darp/v1.0.0/designateAccount/notify"
    final String COL_FISC_REQ	            ="FISC_REQ";            //nvarchar			MAX	‘’		財金/主機 上行
    final String COL_FISC_RES	            ="FISC_RES";            //nvarchar			MAX	‘’		財金/主機 下行
    final String COL_FISC_RC	            ="FISC_RC";             //nvarchar			2	‘’		"財金約定帳號通報結果 01:通報完成 02:非本次規劃帳號03:無此帳號04:重複通報05:無此交易通路06:查無原約定帳號申請通報交易 07:帳戶狀態異常 A0001:通報失敗"
    final String COL_RETRY_DAY	            ="RETRY_DAY";           //nvarchar			23	‘’		重發財金的時間(YYYY/MM/DD HH:MM:SS.SSS)
    final String COL_RETRY_REQ	            ="RETRY_REQ";           //nvarchar			MAX	‘’		重發財金的上行
    final String COL_RETRY_RES	            ="RETRY_RES";           //nvarchar			MAX	‘’		重發財金的下行
    final String COL_STAN	                ="STAN";                //nvarchar			10	‘’		OCSI序號
    final String COL_RTN_CODE	            ="RTN_CODE";            //nvarchar			10	‘’		財金或主機回傳下行的code
    final String COL_FISC_STAN	            ="FISC_STAN";           //nvarchar			10	‘’		財金公司Header，API發送處理序號
    final String COL_FISC_DESTINATIONID	    ="FISC_DESTINATIONID";  //nvarchar			10	‘’		財金公司Header，轉入行銀行代號
    final String COL_FISC_SOURCEID	        ="FISC_SOURCEID";       //nvarchar			10	‘’		財金公司Header，轉出行銀行代號
    final String COL_FISC_TXNINITDATETIME	="FISC_TXNINITDATETIME";//nvarchar			14	‘’		財金公司Header，API交易發起日期時間
    final String COL_FISC_KEYID	            ="FISC_KEYID";          //nvarchar			MAX	‘’		財金公司Header，API Key
    final String COL_IP	                    ="IP";                  //nvarchar			MAX	‘’		來源IP
    final String COL_MF_REQ                 ="MF_REQ";
    final String COL_MF_RES                 ="MF_RES";
    final String COL_SYSINTE_STATUS         ="SYSINTE_STATUS";
    public int insert(SysInteRecordVO vo) {
        log.info(Common.ARROW + "insert" + Common.START_B);
        log.info(Common.VO + vo);
        String SQL = String.format("INSERT INTO %s"
                        + " (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
                        + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                ,TABLE_FiscRecord
                , COL_QID
                , COL_EXEC_DATE
                , COL_EXEC_ACTUAL_DATE
                , COL_API_SID
                , COL_FISC_URL
                , COL_FISC_REQ
                , COL_FISC_RES
                , COL_FISC_RC
                , COL_RETRY_DAY
                , COL_RETRY_REQ
                , COL_RETRY_RES
                , COL_STAN
                , COL_RTN_CODE
                , COL_FISC_STAN
                , COL_FISC_DESTINATIONID
                , COL_FISC_SOURCEID
                , COL_FISC_TXNINITDATETIME
                , COL_FISC_KEYID
                , COL_IP
                , COL_MF_REQ
                , COL_MF_RES
                , COL_SYSINTE_STATUS
        );
        PreparedStatement pstmt = null;
        int code = 0;
        int j = 0;
        try {
            log.info(Common.SQL + SQL);
            pstmt = getConn().prepareStatement(SQL);
            pstmt.setString(++j, vo.getQID                  ());
            pstmt.setString(++j, vo.getEXEC_DATE            ());
            pstmt.setString(++j, vo.getEXEC_ACTUAL_DATE     ());
            pstmt.setString(++j, vo.getAPI_SID              ());
            pstmt.setString(++j, vo.getFISC_URL             ());
            pstmt.setString(++j, vo.getFISC_REQ             ());
            pstmt.setString(++j, vo.getFISC_RES             ());
            pstmt.setString(++j, vo.getFISC_RC              ());
            pstmt.setString(++j, vo.getRETRY_DAY            ());
            pstmt.setString(++j, vo.getRETRY_REQ            ());
            pstmt.setString(++j, vo.getRETRY_RES            ());
            pstmt.setString(++j, vo.getSTAN                 ());
            pstmt.setString(++j, vo.getRTN_CODE             ());
            pstmt.setString(++j, vo.getFISC_STAN            ());
            pstmt.setString(++j, vo.getFISC_DESTINATIONID   ());
            pstmt.setString(++j, vo.getFISC_SOURCEID        ());
            pstmt.setString(++j, vo.getFISC_TXNINITDATETIME ());
            pstmt.setString(++j, vo.getFISC_KEYID           ());
            pstmt.setString(++j, vo.getIP                   ());
            pstmt.setString(++j, vo.getMF_REQ               ());
            pstmt.setString(++j, vo.getMF_RES               ());
            pstmt.setString(++j, vo.getSYSINTE_STATUS       ());

            code = pstmt.executeUpdate();
            pstmt.clearParameters();
            log.info(Common.RESULT + code);
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        } finally {
            close(pstmt);
            log.info(Common.ARROW + "insert" + Common.END_B);
        }
        return code;
    }
    public int updateFINISH(SysInteRecordVO vo) {
        log.info(Common.ARROW + "updateFINISH" + Common.START_B);
        log.info(Common.VO + vo);
        String SQL = String.format("UPDATE %s SET"
                        + " %s = ?, %s = ?, %s = ?, %s = ?, %s = ?"
                        + " WHERE %s = ?"
                ,TABLE_FiscRecord
                , COL_FISC_RES
                , COL_FISC_RC
                , COL_RTN_CODE
                , COL_MF_RES
                , COL_SYSINTE_STATUS

                , COL_QID
        );
        PreparedStatement pstmt = null;
        int code = 0;
        int j = 0;
        try {
            log.info(Common.SQL + SQL);
            pstmt = getConn().prepareStatement(SQL);
            pstmt.setString(++j, vo.getFISC_RES		     ());
            pstmt.setString(++j, vo.getFISC_RC			 ());
            pstmt.setString(++j, vo.getRTN_CODE		     ());
            pstmt.setString(++j, vo.getMF_REQ            ());
            pstmt.setString(++j, vo.getMF_RES            ());
            pstmt.setString(++j, vo.getSYSINTE_STATUS    ());

            pstmt.setString(++j, vo.getQID				 ());

            code = pstmt.executeUpdate();
            pstmt.clearParameters();
            log.info(Common.RESULT + code);
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        } finally {
            close(pstmt);
            log.info(Common.ARROW + "updateFINISH" + Common.END_B);
        }
        return code;
    }
}
