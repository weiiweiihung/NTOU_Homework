package com.ubot.tools.init;

import com.ubot.tools.FiscConfig;
import com.ubot.tools.SysConfig;
import com.ubot.tools.atmpSocket.AtmpSocketUtil;
import com.ubot.tools.rest.EcMap;

public class Trigger {
	
	{
		fire();
	}
	
	public void fire() {
//		MessageUtils.init();
		EcMap.init();
		DataSet.init();
		SysConfig.init();
		FiscConfig.init();
//		RSAUtils.init();
		AtmpSocketUtil.init();
		AtmpSocketUtil.openConnection();
	}
	
}
