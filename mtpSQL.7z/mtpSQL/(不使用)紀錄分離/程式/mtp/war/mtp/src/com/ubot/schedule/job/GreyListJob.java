package com.ubot.schedule.job;

//import com.ubot.db.APIRecord.APIRecordDAO;
//import com.ubot.db.APIRecord.APIRecordTool;
//import com.ubot.db.APIRecord.APIRecordVO;
//import com.ubot.openapi.mtp2fisc.greylist.Mtp2fiscTool;
//import com.ubot.systemIntegrat.fisc.ActFISC;
//import com.ubot.systemIntegrat.fisc.greylist.v1_0_0.notify.NotifyReq;
//import com.ubot.systemIntegrat.fisc.greylist.v1_0_0.notifyCancel.NotifyCancelReq;
//import com.ubot.systemIntegrat.IntegratModel;
//import com.ubot.tools.common.Common;
//import com.ubot.tools.common.JsonTool;
//import com.ubot.tools.common.UniqueUtils;
//import lombok.extern.log4j.Log4j;
//
//import java.util.ArrayList;

//@Log4j
//public class GreyListJob {
//    final String Notify ="MTP0102001";//申請
//    final String NotifyCancel = "MTP0103001";//取消
//    final String sSID = getClass().getSimpleName();
//    public GreyListJob() {
//        log.info(Common.DIVIDER + Common.START + sSID + Common.DIVIDER);
//
//        // select GREY_LIST QUEUE當天沒有跑的
//        // select 出財金未成功、未執行的清單
//        APIRecordDAO daoGreyList = new APIRecordDAO();
//        APIRecordVO voGreyList = new APIRecordVO();
//        voGreyList.setEXEC_DATE(UniqueUtils.getDate());
//        ArrayList<APIRecordVO> resendList = daoGreyList.selectResendFISCData(voGreyList);
//
//        // 得到unsucess的上行
//        resendList.forEach(action->{
//            String sSID = action.getAPI_SID();
//            log.info(sSID + Common.RETRY_B + Common.ARROW + action.getQID() + Common.START_B);
//            IntegratModel integratModel = null;
//            try {
//                if(sSID.equals(Notify))
//                    integratModel = resendFISC_Notify(action);
//                else if(sSID.equals(NotifyCancel))
//                    integratModel = resendFISC_NotifyCancel(action);
//
//            }
//            catch(Exception e){
//                log.error(Common.EXCEPTION,e);
//            }
//            finally {
//                APIRecordVO voRetry = new APIRecordVO();
//                if(integratModel!=null)
//                    if(Mtp2fiscTool.isResHasAPPREPBODY(integratModel)) {
//                        APIRecordTool.unifiedFISCFlag(voRetry, Mtp2fiscTool.getGreyResResult(integratModel));//重送:不管成功或失敗都要update欄位RETRY_DATE,RETRY_REQ,RETRY_RES，並更新財金FLAG:TO_FISC_STATUS,FISC_RC
//                        voRetry.setRETRY_RES(String.valueOf(integratModel.body));
//                    }
//
//                setResendFlag(action,voRetry);
//                daoGreyList.updateRetryData(voRetry);
//                log.info(sSID + Common.RETRY_B + Common.ARROW + action.getQID() + Common.END_B);
//            }
//        });
//
//        log.info(Common.DIVIDER + Common.END + sSID + Common.DIVIDER);
//    }
//
//    private IntegratModel resendFISC_Notify(APIRecordVO action) throws Exception {//resend to fisc
//        NotifyReq req = JsonTool.readValue(action.getFISC_REQ(), NotifyReq.class);
//        if(req!=null) {
//            NotifyReq notifyReq = new NotifyReq();
//            notifyReq.setAccount(req.getAccount());
//            notifyReq.setChannelType(req.getChannelType());
//            notifyReq.setDarpStan(req.getDarpStan());
//            notifyReq.setDarpDateTime(req.getDarpDateTime());
//            return new ActFISC().actNotify(notifyReq
//                    , action.getIN_ACC_BANKCODE(), action.getSTAN());
//        }
//        return null;
//    }
//    private IntegratModel resendFISC_NotifyCancel(APIRecordVO action) throws Exception {//resend to fisc
//        NotifyCancelReq req = JsonTool.readValue(action.getFISC_REQ(), NotifyCancelReq.class);
//        if(req!=null) {
//            NotifyCancelReq notifyCXLReq = new NotifyCancelReq();
//            notifyCXLReq.setAccount(req.getAccount());
//            notifyCXLReq.setChannelType(req.getChannelType());
//            notifyCXLReq.setOrigDarpStan(req.getOrigDarpStan());
//            notifyCXLReq.setOrigDarpDateTime(req.getOrigDarpDateTime());
//            notifyCXLReq.setDarpStan(req.getDarpStan());
//            notifyCXLReq.setDarpDateTime(req.getDarpDateTime());
//            return new ActFISC().actNotifyCancel(notifyCXLReq
//                    , action.getIN_ACC_BANKCODE(), action.getSTAN());
//        }
//        return null;
//    }
//    private void setResendFlag(APIRecordVO action, APIRecordVO voRetry){//update resend data in db
//        voRetry.setRETRY_DAY(UniqueUtils.getDateTime());
//        voRetry.setRETRY_REQ(action.getFISC_REQ());
//        voRetry.setQID(action.getQID());
//    }
//}
