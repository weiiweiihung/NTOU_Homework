package com.ubot.systemIntegrat.fisc;

import com.ubot.api.RestSet.MyException;
import com.ubot.db.SysInteRecord.SysInteRecordTool;
import com.ubot.db.SysInteRecord.SysInteRecordVO;
import com.ubot.db.vo.EastCallVo;
import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.tools.common.Common;
import com.ubot.tools.common.UniqueUtils;
import com.ubot.tools.rest.EcMap;
import lombok.extern.log4j.Log4j;
import org.json.JSONObject;

@Log4j
public class FiscUtils {

    public static IntegratModel send(
            String EcType
            , String req
            , String uuid
            , String bankCode
            , String stan
            , SysInteRecordVO voSysInteRecord
    ) throws Exception {
        EcMap ecmap = new EcMap();
        EastCallVo ecvo = ecmap.get(EcType);

        EastCallVo newVO = setRealSendEastCall(ecvo,bankCode);

        SysInteRecordTool.setCommonINIT(voSysInteRecord, uuid, req, stan, newVO);

//        return sendUtils(parm, txnvo, newVO, bankCode, stan);
        return sendUtils(req, newVO, bankCode, stan, voSysInteRecord);
    }

    /**
     * send request to 財金
     * 收財金response
     */
    private static IntegratModel sendUtils(
            String req
//            , TxnVo txnvo
            , EastCallVo ecvo
            , String sDestinationId //對方行
            , String sStan          //序號
            , SysInteRecordVO voSysInteRecord
    ) throws Exception {
        log.debug("sendUtils req:" + req);
//        log.debug("sendUtils txnvo:"+ txnvo);
        log.debug("sendUtils ecvo:" + ecvo);
        log.debug("sendUtils sDestinationId:" + sDestinationId);
        log.debug("sendUtils sStan:" + sStan);

        checkCanDO(ecvo, req);
//        txnvo.setRequestData(parm);

        IntegratModel result = null;
        if (isSend2fisc(ecvo)) {
//            setFiscTXN_INIT(txnvo,parm);
            EasyCallFisc ecf = setEasyCallFisc(ecvo,req,sDestinationId,sStan);
            result = ecf.send();

//            txnvo.setOutbound(String.valueOf(result.body));
        }
        SysInteRecordTool.setCommonFINISH(voSysInteRecord, result);
//        txnvo.setRTime();
//        txnvo.setResponseData(result!=null? String.valueOf(result.body) :"");
//        txnvo.InsertRecord();
        return result;
    }
//    private static void setFiscTXN_INIT(TxnVo txnvo, String parm){
//        txnvo.setInbound(parm);
//        txnvo.setKeyR("fiscTo");
//    }
    private static EasyCallFisc setEasyCallFisc(EastCallVo ecvo, String parm
            ,String destinationId,String stan) {
        EasyCallFisc ecf = new EasyCallFisc(destinationId,stan);
        ecf.setUrl(ecvo.getUrl());
        ecf.setMethod(ecvo.getMethod());
        ecf.setContentType(ecvo.getContentType());
        ecf.setRName(ecvo.getAuthName());
        ecf.setRPass(ecvo.getAuthPass());
        ecf.setSend_parm(parm);
        ecf.setProxyIP(ecvo.getProxyIP());
        ecf.setProxyPort(ecvo.getProxyPort());
        ecf.setEncode(ecvo.getEncode());

        log.info("Url:" + ecvo.getUrl());
        log.info("RestSend:" + parm);
        return ecf;
    }
    private static boolean isSend2fisc(EastCallVo ecvo) {
        return ecvo.getUrl().contains(Common.MTP)
                || UniqueUtils.checkGreyListProject(ecvo.getEcType());
    }
    private static void checkCanDO(EastCallVo ecvo, String req) throws MyException {
        if (ecvo.getMethod().equals("POST"))
            if (!ecvo.getRequirdParm().equals("none")) {
                String[] parms = ecvo.getRequirdParm().split(",");
                JSONObject input = new JSONObject(req);
                for (String s : parms) {
                    if (!input.has(s))
                        throw new MyException(400, "OEI01", "lostParamater:" + s);
                }
            }
    }
    private static EastCallVo setRealSendEastCall(EastCallVo ecvo,String bankCode){
        EastCallVo newVO = new EastCallVo();
        newVO.setMethod(ecvo.getMethod());
        newVO.setContentType(ecvo.getContentType());
        newVO.setUrl(ecvo.getUrl().replace("{bankId}", bankCode));
        newVO.setRequirdParm(ecvo.getRequirdParm());
        newVO.setAuthName(ecvo.getAuthName());
        newVO.setAuthPass(ecvo.getAuthPass());
        newVO.setProxyIP(ecvo.getProxyIP());
        newVO.setProxyPort(ecvo.getProxyPort());
        newVO.setEncode(ecvo.getEncode());
        newVO.setSdate(ecvo.getSdate());
        newVO.setEcType(ecvo.getEcType());
        return newVO;
    }
}
