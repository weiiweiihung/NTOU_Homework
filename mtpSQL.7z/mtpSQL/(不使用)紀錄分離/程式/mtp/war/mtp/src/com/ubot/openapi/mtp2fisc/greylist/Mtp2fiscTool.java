package com.ubot.openapi.mtp2fisc.greylist;

import com.ubot.db.APIRecord.APIRecordTool;
import com.ubot.db.APIRecord.APIRecordVO;
import com.ubot.openapi.APIRes;
import com.ubot.openapi.OpenAPICommon;
import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.systemIntegrat.fisc.FiscCommon;
import com.ubot.systemIntegrat.hub.HubCommon;
import com.ubot.tools.common.CC;
import com.ubot.tools.common.Common;
import lombok.extern.log4j.Log4j;
import org.json.JSONObject;

import java.util.UUID;

import static com.ubot.db.APIRecord.APIRecordTool.unifiedFISCFlag;
import static com.ubot.systemIntegrat.fisc.FiscCommon.*;

@Log4j
public class Mtp2fiscTool {

    public static void setGLTVO_INIT(
            APIRecordVO vo
            , String sAPIReq
            , String sInAccount
            , String sInBandCode
            , String sOutBandCode
//            , String sDarpStan
            , String sSVC_TYPE ){
        vo.setQID(UUID.randomUUID().toString());//Queue編號KEY9f4493a4-06a3-48a2-8ca4-230510a58605"
        vo.setAPI_REQ(sAPIReq);//open api 上行
        vo.setIN_ACC(sInAccount);//轉入行帳號
        vo.setIN_ACC_BANKCODE(sInBandCode);//轉入行銀行代號
        vo.setOUT_ACC_BANKCODE(sOutBandCode);//轉出行銀行代號(交易發動行)
//        vo.setSTAN(sDarpStan);
        vo.setSVC_TYPE(sSVC_TYPE);
//        vo.setFISC_STAN            (vo.getFISC_STAN           ());
//        vo.setFISC_DESTINATIONID   (vo.getFISC_DESTINATIONID  ());
//        vo.setFISC_SOURCEID        (vo.getFISC_SOURCEID       ());
//        vo.setFISC_TXNINITDATETIME (vo.getFISC_TXNINITDATETIME());
//        vo.setFISC_KEYID           (vo.getFISC_KEYID          ());
        APIRecordTool.setCommonINIT(vo);
    }
    public static void setGLTVO_PROCESS(APIRecordVO vo, String sFiscReq, String sMFReq){
//        vo.setFISC_REQ(sFiscReq);
//        vo.setMF_REQ(sMFReq);
        APIRecordTool.setCommonPROCESS(vo);
    }
    public static void setGLTVO_FINISH(APIRecordVO vo, JSONObject Result
            , IntegratModel integratModel) {
        log.debug("setGLTVO_FINISH vo:" + vo);
        log.debug("setGLTVO_FINISH Result:" + Result);
        log.debug("setGLTVO_FINISH integratModel:" + integratModel);

        if (integratModel != null) {
            if(isResHasAPPREPBODY(integratModel)) {
                String sResult = getGreyResResult(integratModel);
log.debug("財金resultCode:"+sResult);
                if (integratModel.originSys.equals(Common.FISC)) {
//                    vo.setFISC_RES(integratModel.body.toString());//財金下行
                    unifiedFISCFlag(vo, sResult);//財金專用
                    vo.setFISC_RC(sResult);//約定帳號通報結果
                }

//                if (integratModel.originSys.equals(Common.HUB))
//                    vo.setMF_RES(integratModel.body.toString());//財金下行
            }
//            vo.setERR_RESULT(integratModel.errorBody);

            vo.setAPI_RES(Result.toString());
            vo.setRTN_CODE(integratModel.originRc);
            APIRecordTool.setCommonFINISH(vo);
        }
    }
    public static boolean checkMFHasBody(JSONObject hubRes, String strJsonNode){
        boolean b = false;
        if(hubRes.has(HubCommon.RC)
                && hubRes.has(HubCommon.RC2)
                && hubRes.getString(HubCommon.RC).equals(HubCommon.M000)
                && hubRes.getString(HubCommon.RC2).equals(HubCommon.M000)){
            if(hubRes.has(strJsonNode))
                return true;
        } else {
            log.warn("電文下行有誤:"+hubRes);
        }
        return b;
    }

    /**
     * set 電文的response
     */
    public static void setMFRes(JSONObject hubRes
            ,IntegratModel integratModel, JSONObject formatedRes){ // bodyFormat:response is same as fisc response
log.debug("hubRes:"+hubRes);
log.debug("integratModel:"+integratModel);
log.debug("formatedRes:"+formatedRes);
        String rc1 = hubRes.getString(HubCommon.RC);
        String rc2 = hubRes.getString(HubCommon.RC2);
        String resultRc = !rc2.trim().isEmpty() ? rc2 : rc1;

        integratModel.body = formatedRes;
        integratModel.rc = resultRc;
        integratModel.originRc = resultRc;
        integratModel.msg = hubRes.getString(HubCommon.MSG2);
        integratModel.system = Common.HUB;

        if(!rc1.trim().equals(HubCommon.M000)
                || !rc2.trim().equals(HubCommon.M000))
            integratModel.errorBody = hubRes.toString();
log.debug("after integratModel:"+integratModel);
    }
    public static void setAPIResult(JSONObject Result, IntegratModel integratModel){
        Result.put(APIRes.RC, integratModel.rc);
        Result.put(APIRes.MSG, integratModel.msg);
        Result.put(APIRes.SYSTEM, integratModel.system);
        Result.put(APIRes.TIME, integratModel.time);
        Result.put(APIRes.BODY, integratModel.body);
    }
    public static void fisc200Format(IntegratModel integratModel){
        if(integratModel.originRc.equals(FiscCommon.RC.FISC_GREY_200.getMid())){
            integratModel.rc = OpenAPICommon.RC.MTP_P000.getMid();
            integratModel.msg = OpenAPICommon.RC.MTP_P000.getMname();
            integratModel.system = Common.MTP;// + "/" + integratModel.originSys;
        }
    }
    public static void hubM000Format(IntegratModel integratModel){
        if(integratModel.originRc.equals(HubCommon.M000)){
            integratModel.rc  = OpenAPICommon.RC.MTP_P000.getMid();
            integratModel.msg = OpenAPICommon.RC.MTP_P000.getMname();
            integratModel.system = Common.MTP; //+ "/" + integratModel.originSys;
        }
    }
    /**
     *  依電文下行回覆: 規則化代碼及訊息。code(失敗才會帶)其餘情境result會帶值
     * @param fiscCode query/notify/notifyCancelRes.getAppRepBody().getCode()
     * @param fiscResult query/notify/notifyCancelRes.getAppRepBody().getResult()
     * @return CC rc and msg
     */
    public static CC setRcMsg(String fiscCode, String fiscResult){
        CC cc = new CC();
        if(fiscCode.isEmpty())
            cc.setCode(fiscResult);
        else
            cc.setCode(fiscCode);

        cc.setContent(APIRecordVO.FISC_RC.find(cc.getCode()).getContent());
        return cc;
    }
    public static boolean isUBOT(String sBankCode){
        return sBankCode.equals(Common.UBOT_CODE);
    }
    public static boolean isResHasAPPREPBODY(IntegratModel integratModel){
        return integratModel.body != null && integratModel.body.has(GREY_RES_APPREPBODY);
    }
    public static String  getGreyResResult(IntegratModel integratModel){
        String appRepBody = integratModel.body.getJSONObject(GREY_RES_APPREPBODY).toString();
        JSONObject jsonObject = new JSONObject(appRepBody);
        return jsonObject.getString(GREY_RES_RESULT);
    }
}
