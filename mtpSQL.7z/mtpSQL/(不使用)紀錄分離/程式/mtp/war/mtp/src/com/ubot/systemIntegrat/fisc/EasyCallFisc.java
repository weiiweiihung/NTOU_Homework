package com.ubot.systemIntegrat.fisc;

import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.tools.FiscConfig;
import com.ubot.tools.SysConfig;
import com.ubot.tools.common.Common;
import com.ubot.tools.common.UniqueUtils;
import lombok.Data;
import lombok.extern.log4j.Log4j;
import org.json.JSONObject;

import javax.net.ssl.*;
import javax.ws.rs.core.MediaType;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

@Data
@Log4j
public class EasyCallFisc {
    private String Url 			= "";//對方網址
    private String method 		= "";//POST or GET
    private String contentType 	= "";//application/json
    private String rName 		= "";
    private String rPass 		= "";
    private String send_parm 	= "";
    private String proxyIP 		= "none";
    private String proxyPort	= "";
    private String Encode		= "UTF-8";
    private int ResponseCode 	= 0;

    private final String destinationId;
    private final String stan;

    public EasyCallFisc(String destinationId,String stan) {
        this.destinationId = destinationId;
        this.stan = stan;
    }

    public IntegratModel send() throws Exception {
        IntegratModel res = null;
        try {
            res = this.gohttps();
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        }
        return res ;
    }
    private IntegratModel gohttps() throws Exception {

        if(method.equalsIgnoreCase("GET")){
            Url = Url + "?" + send_parm;
        } else {
            method = "POST";
        }

        //==============
        //SSL 驗證
        //=============
        KeyStore clientStore;
        StringBuilder response = new StringBuilder();

        clientStore = KeyStore.getInstance("PKCS12");
        clientStore.load(new FileInputStream(SysConfig.fiscCerLocate), SysConfig.fiscCerPwd.toCharArray());
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(clientStore, "vEryComPleXPw".toCharArray());
        KeyManager[] kms = kmf.getKeyManagers();

        // Assuming that you imported the CA Cert "Subject: CN=MBIIS CA, OU=MBIIS, O=DAIMLER, C=DE"
        // to your cacerts Store.
        KeyStore trustStore = KeyStore.getInstance("JKS");
        trustStore.load(new FileInputStream(SysConfig.ubotCerLocate), SysConfig.ubotCerPwd.toCharArray());

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trustStore);
        TrustManager[] tms = tmf.getTrustManagers();

        final SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kms,tms,new SecureRandom());
        SSLContext.setDefault(sslContext);

        URL obj;
        HttpsURLConnection conn;
        obj = new URL(Url);


        if(!proxyIP.equals("none")) {
            // setup proxy
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIP, Integer.parseInt(proxyPort)));
            conn = (HttpsURLConnection) obj.openConnection(proxy);
        } else {
            conn = (HttpsURLConnection) obj.openConnection();
        }

        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod(method);
        conn.setRequestProperty("Content-Type", contentType);

        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String strDate = sdFormat.format(new Date());

        String sDestinationId = UniqueUtils.formatRightZero(destinationId,7);
        conn.setRequestProperty(FiscCommon.GREY_HEADER_STAN             , stan);
        conn.setRequestProperty(FiscCommon.GREY_HEADER_DESTINATIONID, sDestinationId);
        conn.setRequestProperty(FiscCommon.GREY_HEADER_SOURCEID, FiscConfig.greyXSourceId);
        conn.setRequestProperty(FiscCommon.GREY_HEADER_TXNINITDATETIME, strDate);
        conn.setRequestProperty(FiscCommon.GREY_HEADER_KEYID, FiscConfig.greyXKeyID);
        conn.setRequestProperty(FiscCommon.GREY_HEADER_ACCEPT, MediaType.APPLICATION_JSON);

        log.info("[" + FiscCommon.GREY_HEADER_STAN              + "]" + stan);
        log.info("[" + FiscCommon.GREY_HEADER_DESTINATIONID     + "]" + sDestinationId);
        log.info("[" + FiscCommon.GREY_HEADER_SOURCEID          + "]" + FiscConfig.greyXSourceId);
        log.info("[" + FiscCommon.GREY_HEADER_TXNINITDATETIME   + "]" + strDate);
        log.info("[" + FiscCommon.GREY_HEADER_KEYID             + "]" + FiscConfig.greyXKeyID);
        log.info("[" + FiscCommon.GREY_HEADER_ACCEPT            + "]" + MediaType.APPLICATION_JSON);

        conn.setConnectTimeout(30000);
        conn.setSSLSocketFactory(sslContext.getSocketFactory());
        conn.setDoOutput(true);

        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
        dos.write(send_parm.getBytes(Encode));
        dos.flush();
        dos.close();
        conn.disconnect();

        int resCode = conn.getResponseCode();
        log.debug(Common.FISC + " httpCode:" + resCode);
        IntegratModel res = new IntegratModel();
        if(resCode==200) {
            BufferedReader br = new BufferedReader(
                new InputStreamReader((conn.getInputStream()), Encode));
            String output;
            while ((output = br.readLine()) != null)
                response.append(output);

        }
        log.debug(Common.FISC + " response:" + response);

        res.originRc = String.valueOf(resCode);
        res.originSys = Common.FISC;
        res.body = bodyParser(response.toString(),res);

        log.info("IntegratModel:" + res);
        return res;
    }
    private JSONObject bodyParser(String response, IntegratModel res) {
        JSONObject o = null;
        try {
            o = new JSONObject(response);
        } catch (Exception e){
//            o = new JSONObject("{}");
            res.errorBody = response;
            log.error("★錯誤傳入:"+response);
        }
        return o;
    }
}
