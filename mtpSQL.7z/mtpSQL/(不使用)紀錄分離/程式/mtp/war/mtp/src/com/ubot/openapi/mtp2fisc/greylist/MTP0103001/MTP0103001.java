package com.ubot.openapi.mtp2fisc.greylist.MTP0103001;

import com.ubot.api.RestSet.TException;
import com.ubot.db.APIRecord.APIRecordTool;
import com.ubot.db.APIRecord.APIRecordVO;
import com.ubot.openapi.APIRes;
import com.ubot.openapi.OpenAPICommon;
import com.ubot.openapi.mtp2fisc.greylist.Mtp2fiscTool;
import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.systemIntegrat.fisc.ActFISC;
import com.ubot.systemIntegrat.fisc.greylist.v1_0_0.notifyCancel.NotifyCancelReq;
import com.ubot.tools.common.Common;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import static com.ubot.db.APIRecord.APIRecordVO.SVC_TYPE.A03;
import static com.ubot.openapi.mtp2fisc.greylist.MTP0103001.MTP0103001Req.checkReq;

/**
 * Jenny
 * 內部系統call此api對fisc進行灰名單取消
 */
@Log4j
@NoArgsConstructor
public class MTP0103001 {
    APIRecordVO voAPIRecord;
    IntegratModel integratModel;

    public MTP0103001(HttpServletRequest request) {
        voAPIRecord = new APIRecordVO(request);
    }

    public Response doAPI(MTP0103001Req req) {
        log.info(voAPIRecord.getIP() + Common.API_DIVIDER + Common.START_B + Common.API_DIVIDER);
        log.info(Common.REQ + req);
        JSONObject Result = new JSONObject();
        try {
            integratModel = new IntegratModel();
            if(!checkReq(req, integratModel))
                throw new TException(integratModel);

            Mtp2fiscTool.setGLTVO_INIT(voAPIRecord, req.toString()
                , req.getAccount(), req.getBankCode()
                , Common.UBOT_CODE
//                , req.getDarpStan()
                , A03.getCode());
            APIRecordTool.dbAction(APIRecordVO.API_STATUS.INIT, voAPIRecord);

            //發財金
            NotifyCancelReq NotifyCancelReq = setNotifyCancelReq(req);
            Mtp2fiscTool.setGLTVO_PROCESS(voAPIRecord,NotifyCancelReq.toString(), "");
            APIRecordTool.dbAction(APIRecordVO.API_STATUS.PROCESS, voAPIRecord);

            integratModel = new ActFISC().actNotifyCancel(NotifyCancelReq, req.getBankCode(), req.getDarpStan());
//            integratModel.system = Common.FISC;

            Mtp2fiscTool.fisc200Format(integratModel);
            Mtp2fiscTool.setAPIResult(Result,integratModel);

            Mtp2fiscTool.setGLTVO_FINISH(voAPIRecord,Result, integratModel);
            APIRecordTool.dbAction(APIRecordVO.API_STATUS.FINISH, voAPIRecord);
        }
        catch (TException e) {
            Mtp2fiscTool.setAPIResult(Result,integratModel);
            log.warn(Common.TEXCEPTION + e.msg);
        }
        catch (Exception e) {
            Result.put(APIRes.RC, OpenAPICommon.RC.MTP_P999.getMid());
            Result.put(APIRes.MSG, OpenAPICommon.RC.MTP_P999.getMname());
            log.error(Common.EXCEPTION, e);
        }

        log.info(Common.RES + Result);
        log.info(voAPIRecord.getIP() + Common.API_DIVIDER + Common.END_B + Common.API_DIVIDER);
        return Response.status(200).entity(String.valueOf(Result)).build();
    }
    private NotifyCancelReq setNotifyCancelReq(MTP0103001Req req){
        NotifyCancelReq NotifyCancelReq = new NotifyCancelReq();
        NotifyCancelReq.setAccount          (req.getAccount     ());
        NotifyCancelReq.setChannelType      (req.getChannelType ());
        NotifyCancelReq.setOrigDarpStan		(req.getOrigDarpStan());
        NotifyCancelReq.setOrigDarpDateTime	(req.getOrigDarpDateTime ());
        NotifyCancelReq.setDarpStan         (req.getDarpStan    ());
        NotifyCancelReq.setDarpDateTime     (req.getDarpDateTime());
        return NotifyCancelReq;
    }
}
