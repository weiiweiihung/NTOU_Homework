package com.ubot.db.SysInteRecord;

import com.fasterxml.jackson.annotation.JsonValue;
import com.ubot.systemIntegrat.fisc.FiscCommon;
import com.ubot.tools.common.JsonTool;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SysInteRecordVO {
    public SysInteRecordVO(HttpServletRequest request) {
        this.IP = request.getRemoteAddr();
        this.API_SID = request.getPathInfo().substring(1);

        if(request.getHeader(FiscCommon.GREY_HEADER_STAN)!=null)
            this.FISC_STAN = request.getHeader(FiscCommon.GREY_HEADER_STAN);
        if(request.getHeader(FiscCommon.GREY_HEADER_DESTINATIONID)!=null)
            this.FISC_DESTINATIONID = request.getHeader(FiscCommon.GREY_HEADER_DESTINATIONID);
        if(request.getHeader(FiscCommon.GREY_HEADER_SOURCEID)!=null)
            this.FISC_SOURCEID = request.getHeader(FiscCommon.GREY_HEADER_SOURCEID);
        if(request.getHeader(FiscCommon.GREY_HEADER_TXNINITDATETIME)!=null)
            this.FISC_TXNINITDATETIME = request.getHeader(FiscCommon.GREY_HEADER_TXNINITDATETIME);
        if(request.getHeader(FiscCommon.GREY_HEADER_KEYID)!=null)
            this.FISC_KEYID = request.getHeader(FiscCommon.GREY_HEADER_KEYID);
    }
    @AllArgsConstructor
    public enum SYSINTE_STATUS {
        INIT		("0" , "未執行")
        , FINISH	("1" , "完成")
        , PROCESS	("2" , "處理中")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
    }
    @AllArgsConstructor
    public enum TO_FISC_STATUS{
        INIT		("0" , "未執行")
        , FINISH	("1" , "完成")
        , PROCESS	("2" , "處理中")
        , FAIL	    ("3" , "失敗")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
    }
    @AllArgsConstructor
    public enum FISC_RC{//財金下行回覆，財金約定帳號通報結果
         OK                 ("01"    ,"通報完成")
        ,NonAcc             ("02"    ,"非本次規劃帳號")
        ,NoSuchAcc          ("03"    ,"無此帳號")
        ,RepeatNotify       ("04"    ,"重複通報")
        ,NoSuchChannel      ("05"    ,"無此交易通路")
        ,CheckNoAccount     ("06"    ,"查無原約定帳號申請通報交易")
        ,AbnormalAcc        ("07"    ,"帳戶狀態異常")
        ,FAIL               ("A0001" ,"通報失敗")
        ;
        private final String code;
        @Getter private final String content;

        @JsonValue
        public String getCode() {return code;}
        public static FISC_RC find(String val) {
            return Arrays.stream(values())
                    .filter(predicate
                            -> 	predicate.code.equals(val)
                            ||	predicate.content.equals(val))
                    .findFirst()
                    .orElse(null);
        }
    }

    private String QID	                ="";//varchar			36	‘’		"Queue編號KEY 9f4493a4-06a3-48a2-8ca4-230510a58605"
    private String EXEC_DATE	        ="";//nvarchar			10	‘’		交易執行日(YYYY/MM/DD)
    private String EXEC_ACTUAL_DATE	    ="";//nvarchar			23	‘’		實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
    private String API_SID	            ="";//nvarchar			10	‘’		API編號
    private String FISC_URL	            ="";//nvarchar			MAX	‘’		"財金電文url，例如 https://openapigw.fisc-test.com.tw/darp/v1.0.0/designateAccount/notify"
    private String FISC_REQ	            ="";//nvarchar			MAX	‘’		財金/主機 上行
    private String FISC_RES	            ="";//nvarchar			MAX	‘’		財金/主機 下行
    private String FISC_RC	            ="";//nvarchar			2	‘’		"財金約定帳號通報結果 01:通報完成02:非本次規劃帳號03:無此帳號04:重複通報05:無此交易通路06:查無原約定帳號申請通報交易07:帳戶狀態異常 A0001:通報失敗"
    private String RETRY_DAY	        ="";//nvarchar			23	‘’		重發財金的時間(YYYY/MM/DD HH:MM:SS.SSS)
    private String RETRY_REQ	        ="";//nvarchar			MAX	‘’		重發財金的上行
    private String RETRY_RES	        ="";//nvarchar			MAX	‘’		重發財金的下行
    private String STAN	                ="";//nvarchar			10	‘’		OCSI序號
    private String RTN_CODE	            ="";//nvarchar			10	‘’		財金或主機回傳下行的code
    private String FISC_STAN	        ="";//nvarchar			10	‘’		財金公司Header，API發送處理序號
    private String FISC_DESTINATIONID	="";//nvarchar			10	‘’		財金公司Header，轉入行銀行代號
    private String FISC_SOURCEID	    ="";//nvarchar			10	‘’		財金公司Header，轉出行銀行代號
    private String FISC_TXNINITDATETIME	="";//nvarchar			14	‘’		財金公司Header，API交易發起日期時間
    private String FISC_KEYID	        ="";//nvarchar			MAX	‘’		財金公司Header，API Key
    private String IP	                ="";//nvarchar			MAX	‘’		來源IP
    private String MF_REQ               ="";
    private String MF_RES               ="";
    private String SYSINTE_STATUS	    ="";//nvarchar			1	‘’		API狀態(0:未執行，1:完成，2:處理中 )

    public static String encodeFormSQL(String s) {return s != null && !s.isEmpty() ? s : "";}

    @Override
    public String toString() {return JsonTool.format2Json(this);}
}
