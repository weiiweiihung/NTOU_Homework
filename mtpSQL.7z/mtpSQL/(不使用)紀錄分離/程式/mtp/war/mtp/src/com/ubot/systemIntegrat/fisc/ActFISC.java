package com.ubot.systemIntegrat.fisc;

import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.systemIntegrat.fisc.greylist.v1_0_0.notify.NotifyReq;
import com.ubot.systemIntegrat.fisc.greylist.v1_0_0.notifyCancel.NotifyCancelReq;
import com.ubot.systemIntegrat.fisc.greylist.v1_0_0.query.QueryReq;
import lombok.extern.log4j.Log4j;

@Log4j
public class ActFISC {
    final String query = "grey_mtp2fisc_query";
    final String notify = "grey_mtp2fisc_notify";
    final String notifyCancel = "grey_mtp2fisc_notifyCancel";

    /**
     * (1)依據資料庫設定TxnRecord(url)為內含mtp即為發送給財金的判斷
     * (2)發給財金request
     * (3)取得response
     * (4)紀錄dbLog(TxnRecord)
     *
     * @return 財金response
     */
    public IntegratModel actQuery(QueryReq queryReq
            , String sBandCode, String sStan) throws Exception {
        String acc = queryReq.getAccount();

        QueryReq fReq = new QueryReq();
        fReq.setAccount(acc);

//        return FiscUtils.send(query, fReq.toString(), "", sBandCode, sStan);
        return FiscUtils.send(query, fReq.toString(), sBandCode, sStan);
    }
    /**
     * (1)依據資料庫設定TxnRecord(url)為內含mtp即為發送給財金的判斷
     * (2)發給財金request
     * (3)取得response
     * (4)紀錄dbLog(TxnRecord)
     *
     * @return 財金response
     */
    public IntegratModel actNotify(NotifyReq fiscReq
            , String sInBandCode, String sStan) throws Exception {

        NotifyReq fReq = new NotifyReq();
        fReq.setAccount(fiscReq.getAccount());
        fReq.setChannelType(fiscReq.getChannelType());
        fReq.setDarpStan(fiscReq.getDarpStan());
        fReq.setDarpDateTime(fiscReq.getDarpDateTime());

//        return FiscUtils.send(notify, fReq.toString(), "", sInBandCode, sStan);
        return FiscUtils.send(notify, fReq.toString(), sInBandCode, sStan);
    }
    public IntegratModel actNotifyCancel(NotifyCancelReq fiscReq
            , String sInBandCode, String sStan) throws Exception {
        NotifyCancelReq fReq = new NotifyCancelReq();
        fReq.setAccount(fiscReq.getAccount());
        fReq.setChannelType(fiscReq.getChannelType());
        fReq.setOrigDarpStan(fiscReq.getOrigDarpStan());
        fReq.setOrigDarpDateTime(fiscReq.getOrigDarpDateTime());
        fReq.setDarpStan(fiscReq.getDarpStan());
        fReq.setDarpDateTime(fiscReq.getDarpDateTime());

//        return FiscUtils.send(notifyCancel, fReq.toString(), "", sInBandCode, sStan);
        return FiscUtils.send(notifyCancel, fReq.toString(), sInBandCode, sStan);
    }
}
