package com.ubot.openapi.fisc2mtp.greylist.query;

import com.ubot.api.RestSet.TException;
import com.ubot.db.APIRecord.APIRecordTool;
import com.ubot.db.APIRecord.APIRecordVO;
import com.ubot.db.SysInteRecord.SysInteRecordVO;
import com.ubot.openapi.fisc2mtp.greylist.Fisc2mtpTool;
import com.ubot.openapi.ConvertModel;
import com.ubot.openapi.mtp2fisc.greylist.Mtp2fiscTool;
import com.ubot.systemIntegrat.IntegratModel;
import com.ubot.systemIntegrat.hub.ActHUB;
import com.ubot.systemIntegrat.hub.HQ0010J500.HQ0010J500Req;
import com.ubot.systemIntegrat.hub.HQ0010J500.HQ0010J500Res;
import com.ubot.tools.common.Common;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import static com.ubot.db.APIRecord.APIRecordVO.SVC_TYPE.B01;
import static com.ubot.openapi.fisc2mtp.greylist.query.QueryReq.checkReq;

/*** 財金call此api對主機進行查詢 */
@Log4j
@NoArgsConstructor
public class Query {
    APIRecordVO voGreyList;
    SysInteRecordVO voFiscRecord;
    IntegratModel integratModel;

    public Query(HttpServletRequest request) {
        voGreyList = new APIRecordVO(request);
        voFiscRecord = new SysInteRecordVO(request);
    }

    public Response doAPI(QueryReq req) {
        log.info(voGreyList.getIP() + Common.API_DIVIDER + Common.START_B + Common.API_DIVIDER);
        log.info(Common.REQ + req);
        JSONObject Result = new JSONObject();
        try {
            integratModel = new IntegratModel();
            if(!checkReq(req, integratModel, voFiscRecord))
                throw new TException(integratModel);

            Mtp2fiscTool.setGLTVO_INIT(voGreyList, req.toString()
                , req.getAccount(), Common.UBOT_CODE
                , voFiscRecord.getFISC_SOURCEID()
//                , voGreyList.getFISC_STAN()
                , B01.getCode());
            APIRecordTool.dbAction(APIRecordVO.API_STATUS.INIT,voGreyList);

            HQ0010J500Req req10j5 = setReq10j5(req, voFiscRecord);
            Mtp2fiscTool.setGLTVO_PROCESS(voGreyList, "", req10j5.toString());
            APIRecordTool.dbAction(APIRecordVO.API_STATUS.PROCESS,voGreyList);

            JSONObject hubRes = new ActHUB().send10J5(req10j5);
            JSONObject fisc10j5 = null;
            if(Mtp2fiscTool.checkMFHasBody(hubRes, HQ0010J500Res.T19D))
                fisc10j5 = ConvertModel.formatHQ10J5ResToFisc_QueryRes(hubRes);
            Mtp2fiscTool.setMFRes(hubRes, integratModel, fisc10j5);

            Fisc2mtpTool.setAPIResult(Result, integratModel);

            Mtp2fiscTool.setGLTVO_FINISH(voGreyList, Result, integratModel);
            APIRecordTool.dbAction(APIRecordVO.API_STATUS.FINISH, voGreyList);
        }
        catch (TException e) {
            Fisc2mtpTool.setAPIResultErr(Result, integratModel);
            log.warn(Common.TEXCEPTION + e.msg);
        }
        catch (Exception e) {
            Fisc2mtpTool.setAPIResultErr(Result, integratModel);
            log.error(Common.EXCEPTION, e);
        }

        log.info(Common.RES + Result);
        log.info(voGreyList.getIP() + Common.API_DIVIDER + Common.END_B + Common.API_DIVIDER);
        return Response.status(200).entity(String.valueOf(Result)).build();
    }

    private static HQ0010J500Req setReq10j5(QueryReq req, SysInteRecordVO voFiscRecord) {
        HQ0010J500Req req10j5 = new HQ0010J500Req();
        req10j5.setTraBank(voFiscRecord.getFISC_SOURCEID());//轉出行(交易發動行)
        req10j5.ToBank	= Common.UBOT_CODE;//-3	轉入行	Ex: 822
        req10j5.ToAcc	= req.getAccount(); //-16	轉入帳號	Ex:0000000123456789
        req10j5.Sp2_1	= HQ0010J500Req.Sp2_1enum.QUERY.getCode(); //-2	功能代號	１查詢２申請３取消
        return req10j5;
    }
}
