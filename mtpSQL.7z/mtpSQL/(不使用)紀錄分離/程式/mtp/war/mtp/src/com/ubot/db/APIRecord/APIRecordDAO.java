package com.ubot.db.APIRecord;

import com.ubot.db.ConnectControl;
import com.ubot.tools.common.Common;
import lombok.extern.log4j.Log4j;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

@Log4j
public class APIRecordDAO extends ConnectControl {
    final String TABLE_APIRecord 		="APIRecord"		;

    final String COL_QID	            ="QID"				;//nvarchar			36	‘’		"Queue編號KEY 9f4493a4-06a3-48a2-8ca4-230510a58605"
    final String COL_EXEC_DATE	    	="EXEC_DATE"		;//nvarchar			10	‘’		交易執行日(YYYY/MM/DD)
    final String COL_EXEC_ACTUAL_DATE	="EXEC_ACTUAL_DATE"	;//nvarchar			23	‘’		實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
    final String COL_API_SID	        ="API_SID"			;//nvarchar			10	‘’		API編號
    final String COL_API_REQ	        ="API_REQ"			;//nvarchar			MAX	‘’		open api 上行
    final String COL_API_RES	        ="API_RES"			;//nvarchar			MAX	‘’		open api 下行
    final String COL_API_STATUS	    	="API_STATUS"		;//nvarchar			1	‘’		API狀態(0:未執行，1:完成，2:處理中 )
    final String COL_IP	            	="IP"				;//nvarchar			MAX	‘’		來源IP
    final String COL_TO_FISC_STATUS		="TO_FISC_STATUS"	;//nvarchar			1	‘’		送至財金的狀態(0:未執行，1:成功，2:處理中，3失敗 )若當天不成功3或者是空，要重發至成功為止
    final String COL_STATUS	        	="STATUS"			;//nvarchar			2	‘’		狀態00:正常,99:註銷
    final String COL_IN_ACC	        	="IN_ACC"			;//nvarchar			20	‘’		轉入行帳號
    final String COL_IN_ACC_BANKCODE	="IN_ACC_BANKCODE"	;//nvarchar			10	‘’		轉入行銀行代號
    final String COL_OUT_ACC	        ="OUT_ACC"			;//nvarchar			20	‘’		轉出行帳號
    final String COL_OUT_ACC_BANKCODE	="OUT_ACC_BANKCODE"	;//nvarchar			10	‘’		轉出行銀行代號
    final String COL_SVC_TYPE	        ="SVC_TYPE"			;//nvarchar			10	‘’		"A01(MTP發財金查詢), A02(MTP發財金申請), A03(MTP發財金取消) ；B01(財金發MTP查詢), B02(財金發MTP申請), B03(財金發MTP取消)A: MTP→FISC B: FISC→MTP01:查詢02:申請03:取消"
    final String COL_RTN_CODE	        ="RTN_CODE"			;//nvarchar			10	‘’		財金或主機回傳下行的code
    final String COL_FISC_RC	        ="FISC_RC"          ;//nvarchar			10	‘’		通報結果

    public int insert(APIRecordVO vo) {
        log.info(Common.ARROW + "insert" + Common.START_B);
        log.info(Common.VO + vo);
        String SQL = String.format("INSERT INTO %s"
                        + " (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
                        + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                , TABLE_APIRecord

                , COL_QID
                , COL_EXEC_DATE
                , COL_EXEC_ACTUAL_DATE
                , COL_API_SID
                , COL_API_REQ
                , COL_API_RES
                , COL_API_STATUS
                , COL_IP
                , COL_TO_FISC_STATUS
                , COL_STATUS
                , COL_IN_ACC
                , COL_IN_ACC_BANKCODE
                , COL_OUT_ACC
                , COL_OUT_ACC_BANKCODE
                , COL_SVC_TYPE
                , COL_RTN_CODE
                , COL_FISC_RC
        );
        PreparedStatement pstmt = null;
        int code = 0;
        int j = 0;
        try {
            log.info(Common.SQL + SQL);
            pstmt = getConn().prepareStatement(SQL);
            pstmt.setString(++j, vo.getQID	            ());
            pstmt.setString(++j, vo.getEXEC_DATE	    ());
            pstmt.setString(++j, vo.getEXEC_ACTUAL_DATE	());
            pstmt.setString(++j, vo.getAPI_SID	        ());
            pstmt.setString(++j, vo.getAPI_REQ	        ());
            pstmt.setString(++j, vo.getAPI_RES	        ());
            pstmt.setString(++j, vo.getAPI_STATUS	    ());
            pstmt.setString(++j, vo.getIP	            ());
            pstmt.setString(++j, vo.getTO_FISC_STATUS	());
            pstmt.setString(++j, vo.getSTATUS	        ());
            pstmt.setString(++j, vo.getIN_ACC	        ());
            pstmt.setString(++j, vo.getIN_ACC_BANKCODE	());
            pstmt.setString(++j, vo.getOUT_ACC	        ());
            pstmt.setString(++j, vo.getOUT_ACC_BANKCODE	());
            pstmt.setString(++j, vo.getSVC_TYPE	        ());
            pstmt.setString(++j, vo.getRTN_CODE	        ());
            pstmt.setString(++j, vo.getFISC_RC          ());

            code = pstmt.executeUpdate();
            pstmt.clearParameters();
            log.info(Common.RESULT + code);
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        } finally {
            close(pstmt);
            log.info(Common.ARROW + "insert" + Common.END_B);
        }
        return code;
    }
    public int updatePROCESS(APIRecordVO vo) {
        log.info(Common.ARROW + "updatePROCESS" + Common.START_B);
        log.info(Common.VO + vo);
        String SQL = String.format("UPDATE %s SET"
                        + " %s = ?, %s = ?"
                        + " WHERE %s = ?"
                ,TABLE_APIRecord
                , COL_API_STATUS
                , COL_TO_FISC_STATUS

                , COL_QID
        );
        PreparedStatement pstmt = null;
        int code = 0;
        int j = 0;
        try {
            log.info(Common.SQL + SQL);
            pstmt = getConn().prepareStatement(SQL);
            pstmt.setString(++j, vo.getAPI_STATUS		 ());
            pstmt.setString(++j, vo.getTO_FISC_STATUS	 ());

            pstmt.setString(++j, vo.getQID				 ());

            code = pstmt.executeUpdate();
            pstmt.clearParameters();
            log.info(Common.RESULT + code);
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        } finally {
            close(pstmt);
            log.info(Common.ARROW + "updatePROCESS" + Common.START_B);
        }
        return code;
    }
    public int updateFINISH(APIRecordVO vo) {
        log.info(Common.ARROW + "updateFINISH" + Common.START_B);
        log.info(Common.VO + vo);
        String SQL = String.format("UPDATE %s SET"
                        + " %s = ?, %s = ? , %s = ? , %s = ?, %s = ?"
                        + " WHERE %s = ?"
                ,TABLE_APIRecord
                , COL_API_RES
                , COL_API_STATUS
                , COL_TO_FISC_STATUS
                , COL_FISC_RC
                , COL_RTN_CODE

                , COL_QID
        );
        PreparedStatement pstmt = null;
        int code = 0;
        int j = 0;
        try {
            log.info(Common.SQL + SQL);
            pstmt = getConn().prepareStatement(SQL);
            pstmt.setString(++j, vo.getAPI_RES			 ());
            pstmt.setString(++j, vo.getAPI_STATUS		 ());
            pstmt.setString(++j, vo.getTO_FISC_STATUS	 ());
            pstmt.setString(++j, vo.getFISC_RC			 ());
            pstmt.setString(++j, vo.getRTN_CODE		     ());

            pstmt.setString(++j, vo.getQID				 ());

            code = pstmt.executeUpdate();
            pstmt.clearParameters();
            log.info(Common.RESULT + code);
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        } finally {
            close(pstmt);
            log.info(Common.ARROW + "updateFINISH" + Common.END_B);
        }
        return code;
    }
    public ArrayList<APIRecordVO> selectResendFISCData(APIRecordVO vo){
        log.info(Common.ARROW + "selectResendFISCData" + Common.START_B);
        log.info(Common.VO + vo);
        String SQL = String.format("select * from %s" +
                        " where %s = ?" +
                        " and %s != ?" +
                        " and %s in (?, '')" +
                        " and %s in (? , ?)"+
                        " order by %s"
                ,TABLE_APIRecord
                , COL_EXEC_DATE
                , COL_TO_FISC_STATUS
                , COL_FISC_RC
                , COL_SVC_TYPE

                , COL_EXEC_ACTUAL_DATE
        );
        PreparedStatement pstmt = null;
        ArrayList<APIRecordVO> out = new ArrayList<>();
        int i = 0;
        try {
            log.info(Common.SQL + SQL);
            pstmt = getConn().prepareStatement(SQL);
            pstmt.setString(++i , vo.getEXEC_DATE());
            pstmt.setString(++i , APIRecordVO.TO_FISC_STATUS.FINISH.getCode());
            pstmt.setString(++i , APIRecordVO.FISC_RC.CheckNoAccount.getCode());
            pstmt.setString(++i , APIRecordVO.SVC_TYPE.A02.getCode());
            pstmt.setString(++i , APIRecordVO.SVC_TYPE.A03.getCode());
            out = setListGreyListVO(pstmt);
            pstmt.clearParameters();
            log.info(Common.RESULT + out);
        } catch(Exception e) {
            log.error(Common.EXCEPTION, e);
        } finally {
            close(pstmt);
            log.info(Common.ARROW + "selectResendFISCData" + Common.END_B);
        }
        return out;
    }
    private ArrayList<APIRecordVO> setListGreyListVO(PreparedStatement pstmt) {
        int j = 0;
        ResultSet rs = null;
        ArrayList<APIRecordVO> out = new ArrayList<>();
        try{
            rs = pstmt.executeQuery();
            while (rs.next()) {
                out.add(new APIRecordVO(
                        APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                        , APIRecordVO.encodeFormSQL(rs.getString(++j).trim())
                ));
                j = 0;
            }
        } catch(SQLException e) {
            log.error(Common.SQLEXCEPTION, e);
        } finally {
            closeRS(rs);
        }
        return out;
    }
//    public void updateRetryData(APIRecordVO vo) {
//        log.info(Common.ARROW + "updateRetryData" + Common.START_B);
//        log.info(Common.VO + vo);
//        String SQL = String.format("UPDATE %s SET"
//                        + " %s = ?, %s = ?, %s = ?, %s = ?, %s = ?"
//                        + " WHERE %s = ?"
//                ,TABLE_GreyList
//                , COL_RETRY_DAY
//                , COL_RETRY_REQ
//                , COL_RETRY_RES
//                , COL_FISC_RC
//                , COL_TO_FISC_STATUS
//
//                , COL_QID
//        );
//        PreparedStatement pstmt = null;
//        int j = 0;
//        try {
//            log.info(Common.SQL + SQL);
//            pstmt = getConn().prepareStatement(SQL);
//            pstmt.setString(++j, vo.getRETRY_DAY	 ());
//            pstmt.setString(++j, vo.getRETRY_REQ	 ());
//            pstmt.setString(++j, vo.getRETRY_RES     ());
//            pstmt.setString(++j, vo.getFISC_RC	     ());
//            pstmt.setString(++j, vo.getTO_FISC_STATUS());
//
//            pstmt.setString(++j, vo.getQID			 ());
//
//            int code = pstmt.executeUpdate();
//            pstmt.clearParameters();
//            log.info(Common.RESULT + code);
//        } catch(Exception e) {
//            log.error(Common.EXCEPTION, e);
//        } finally {
//            close(pstmt);
//            log.info(Common.ARROW + "updateRetryData" + Common.END_B);
//        }
//    }
}
