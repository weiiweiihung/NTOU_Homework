CREATE TABLE SysInteRecord (
	QID						[nvarchar](36)	NOT NULL DEFAULT('')--‘’		"Queue編號KEY9f4493a4-06a3-48a2-8ca4-230510a58605"
	,EXEC_DATE				[nvarchar](10)	NOT NULL DEFAULT('')--‘’		交易執行日(YYYY/MM/DD)
	,EXEC_ACTUAL_DATE		[nvarchar](23)	NOT NULL DEFAULT('')--‘’		實際交易執行日(YYYY/MM/DD HH:MM:SS.SSS)
	,API_SID				[nvarchar](10)	NOT NULL DEFAULT('')--‘’		API編號
	,FISC_URL				[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		"財金電文url，例如https://openapigw.fisc-test.com.tw/darp/v1.0.0/designateAccount/notify"
	,FISC_REQ				[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		財金/主機 上行
	,FISC_RES				[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		財金/主機 下行
	,FISC_RC				[nvarchar](10)	NOT NULL DEFAULT('')--‘’		"財金約定帳號通報結果01:通報完成02:非本次規劃帳號03:無此帳號04:重複通報0506:查無原約定帳號申請通報交易A0001:通報失敗"
	,RETRY_DAY				[nvarchar](23)	NOT NULL DEFAULT('')--‘’		重發財金的時間(YYYY/MM/DD HH:MM:SS.SSS)
	,RETRY_REQ				[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		重發財金的上行
	,RETRY_RES				[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		重發財金的下行
	,STAN					[nvarchar](10)	NOT NULL DEFAULT('')--‘’		OCSI序號
	,RTN_CODE				[nvarchar](10)	NOT NULL DEFAULT('')--‘’		財金或主機回傳下行的code
	,FISC_STAN				[nvarchar](10)	NOT NULL DEFAULT('')--‘’		財金公司Header，API發送處理序號
	,FISC_DESTINATIONID		[nvarchar](10)	NOT NULL DEFAULT('')--‘’		財金公司Header，轉入行銀行代號
	,FISC_SOURCEID			[nvarchar](10)	NOT NULL DEFAULT('')--‘’		財金公司Header，轉出行銀行代號
	,FISC_TXNINITDATETIME	[nvarchar](14)	NOT NULL DEFAULT('')--‘’		財金公司Header，API交易發起日期時間
	,FISC_KEYID				[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		財金公司Header，API Key
	,IP						[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		來源IP
	,MF_REQ					[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		主機上行
	,MF_RES					[nvarchar](MAX)	NOT NULL DEFAULT('')--‘’		主機下行
	,SYSINTE_STATUS			[nvarchar](1)	NOT NULL DEFAULT('')
)
