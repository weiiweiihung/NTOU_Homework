SELECT * from SERVICES 
select * from CUSTOMER c 

select * from FUND_QUEUE 
where FUNDQ_FCID ='FC20220321162830827'
order by FUNDQ_EXEC_DATE DESC --FUND2022 03 22 11 10 19 640

select * from EJ2HUB 
where CID ='76240923A'
order by INBOUNDTIME DESC 

select * from EJ2HUB eh  where CLASSNAME ='SC050201002DO'and CID ='76240923A' and TXID =
'FC20220321162830827' order by INBOUNDTIME DESC

ELSUBList
dataELSUB2.get(0).getSUBO65()

select * from FUND_QUEUE 
where FUNDQ_FCID ='FC20220107161630748'
order by FUNDQ_EXEC_DATE DESC 

select * from CUSTOMER where CID ='89744573A'

select * from MAPSF where CID like 'qmo%'
select * from API a where API_ID like 'SC04050%'

select * from [MAPSF] where CID ='F126365897A'

select * from MAPSF where CID ='96919464A' and  SID ='SC05-03-020'

INSERT INTO	[MAPSF] (CID, SID, FID, STATUS) 
SELECT	CID, 'SC05-01-010', 'F001', '00' FROM [CUSTOMER] 
WHERE MTYPE = '1' AND SITEMS = 'A' AND STATUS = '00'

select * FROM MAPSF where CID ='A220688852A'


select * from CUSTOMER where CID ='84742479A'

select * from API where API_ID ='SC050500008'

select * FROM [myebankLOGDB].[dbo].[EJ2HUB] WITH(NOLOCK) 
where CID ='84742479A'
order by INBOUNDTIME DESC 

select * from BATCHLIST WHERE BID = 'B016'
