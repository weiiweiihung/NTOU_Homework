-- 對HUB測試環境
-- insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
-- , AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
-- values ('NM00000001'
-- ,'http://172.16.45.135:8080/EaiHub/resCommon/NotesMail'
-- ,'POST'
-- ,'application/json'
-- ,'mtp'
-- ,'mtp'
-- ,'none'
-- ,'none'
-- ,'none'
-- ,'UTF-8'
-- ,'20231220');


-- 對HUB正式環境
insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
, AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
values ('NM00000001'
,'http://172.16.5.105:8080/EaiHub/resCommon/NotesMail'
,'POST'
,'application/json'
,'mtp'
,'mtp'
,'none'
,'none'
,'none'
,'UTF-8'
,'20231220');