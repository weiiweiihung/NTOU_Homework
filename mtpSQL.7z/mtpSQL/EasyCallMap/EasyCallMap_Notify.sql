-- 對財金測試環境
-- insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
-- , AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
-- values ('grey_mtp2fisc_notify','https://openapigw.fisc-test.com.tw/darp/v1.0.0/{bankId}/designateAccount/notify','POST','application/json'
--        ,'none','none','none','none','none','UTF-8','20231220');
	   
-- 對財金正式環境
insert into EasyCallMap (EcType, Url, Method, ContentType, AuthName
, AuthPass, RequirdParm, ProxyIP, ProxyPort, Encode, Sdate)
values ('grey_mtp2fisc_notify','https://openapigw.fisc.com.tw/darp/v1.0.0/{bankId}/designateAccount/notify','POST','application/json'
       ,'none','none','none','none','none','UTF-8','20231220');